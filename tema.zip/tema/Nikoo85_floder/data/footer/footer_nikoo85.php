<?php eval(base64_decode('CiBnb3RvIGpvWHZhOyBYZDBNMjogZWNobyAkd21jcC0+dXN0KCk7IGdvdG8gUjFSbDM7IEhUYWpsOiA/PgpOaWtvbzg1X2Zsb2Rlci9hcHAvcHVibGljL2NsaWVudC92ZXN0YS9hc3NldHMvanMvYm9vdHN0cmFwLm1pbi5qcyI+PC9zY3JpcHQ+PHNjcmlwdCBzcmM9Ijw/cGhwICBnb3RvIEpjRTlJOyBxYWN4WTogPz4KTmlrb284NV9mbG9kZXIvYXBwL3B1YmxpYy9jbGllbnQvdmVzdGEvYXNzZXRzL2pzL21haW4uanMiPjwvc2NyaXB0PjxkaXYgY2xhc3M9ImNvbC1tZC0xMiI+PGRpdiBjbGFzcz0iY29sLW1kLTYgY29sLW1kLW9mZnNldC0zIj48ZGl2IGNsYXNzPSJ0ZXh0LWNlbnRlciJzdHlsZT0ibWFyZ2luLXRvcDo1cHg7bWFyZ2luLWJvdHRvbTo1cHg7Y29sb3I6I2IxYjFiMSI+Q29weXJpZ2h0IMKpIGJ5IE5pa29vODU8YSBocmVmPSJodHRwczovL2ZvcnVtLnR1cmttbW8uY29tL3V5ZS8yMTUwMTM0LW5pa29vODUvIj48L2E+IC0gMjAyMDxicj5Uw7xtIGhha2xhcsSxIHNha2zEsWTEsXIgdmUgPGEgaHJlZj0iaHR0cHM6Ly9mb3J1bS50dXJrbW1vLmNvbS91eWUvMjE1MDEzNC1uaWtvbzg1LyI+PD9waHAgIGdvdG8gWGQwTTI7IE53UEtUOiBlY2hvIFdNX3RlbWE7IGdvdG8gSFRhamw7IEpjRTlJOiBlY2hvIFdNX3RlbWE7IGdvdG8gcWFjeFk7IGpvWHZhOiA/Pgo8c2NyaXB0IHNyYz0iaHR0cHM6Ly9hamF4Lmdvb2dsZWFwaXMuY29tL2FqYXgvbGlicy9qcXVlcnkvMS4xMi40L2pxdWVyeS5taW4uanMiPjwvc2NyaXB0PjxzY3JpcHQgc3JjPSI8P3BocCAgZ290byBOd1BLVDsgUjFSbDM6ID8+CjwvYT5tw7xsa2l5ZXRpbmRlZGlyLjxicj48YSBocmVmPSJodHRwczovL2ZvcnVtLnR1cmttbW8uY29tL3V5ZS8yMTUwMTM0LW5pa29vODUvInRhcmdldD0iX2JsYW5rInRpdGxlPSIjIj5OaWtvbzg1IMSwbGV0acWfaW08L2E+IC0gV2hhdHNBUFAndGFuIMSwbGV0acWfaW08YSBocmVmPSJodHRwczovL2FwaS53aGF0c2FwcC5jb20vc2VuZD9waG9uZT0wMTM4Njc0MjMzMTcmdGV4dD1NZXJoYWJhJTIwQmVuJTIwVHVya21tb2RhbiUyMFRlbWElMjBIYWtrJUM0JUIxbmRhJTIwQmlyJTIwS2ElQzMlQTclMjBTb3J1bSUyME9sYWNha3QlQzQlQjEiPjxzcGFuIGNsYXNzPSJfX2NmX2VtYWlsX18iZGF0YS1jZmVtYWlsPSJodHRwczovL2FwaS53aGF0c2FwcC5jb20vc2VuZD9waG9uZT0wMTM4Njc0MjMzMTcmdGV4dD1NZXJoYWJhJTIwQmVuJTIwVHVya21tb2RhbiUyMFRlbWElMjBIYWtrJUM0JUIxbmRhJTIwQmlyJTIwS2ElQzMlQTclMjBTb3J1bSUyME9sYWNha3QlQzQlQjEiPiBIZW1lbiDEsGxldGnFn2ltZSBHZcOnPC9zcGFuPjwvYT4gPGEgaHJlZj0iaHR0cHM6Ly9mb3J1bS50dXJrbW1vLmNvbS91eWUvMjE1MDEzNC1uaWtvbzg1LyJ0YXJnZXQ9Il9ibGFuayI+PGltZyBzcmM9Imh0dHA6Ly9oaXBwZXJkbnMuY29tL2xpc2Fuc19oaXptZXRpL2xvZ28ucG5nInN0eWxlPSJkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMHB4O21hcmdpbi1yaWdodDphdXRvO21hcmdpbi1sZWZ0OmF1dG8iYWx0PSIjIj48L2E+PC9kaXY+PC9kaXY+PC9kaQ==')); ?>



<div id="yukari" class="yukari_don" data-toggle="tooltip" data-placement="left" title="" data-original-title="Sayfanın başına dönmek için tıklayınız." style="display: none"><i class="glyphicon glyphicon-chevron-up"></i></div>

<script src="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/assets/js/notify.js"></script>
<script type="text/javascript" src="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/assets/js/fancybox.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var screenSize = $(window).height();
        var compareW = 767;
        if (screenSize > 0 && screenSize < compareW) {
            var fancy_a = 740;
            var fancy_b = 550;
            var fancy_c = "ishopbg-small";
            var fancy_d = "13px";
            var fancy_e = "3px";
            var fancy_f = "13px";
            var fancy_g = 754;
            var fancy_h = 574;
            var fancy_i = 6;
            var fancy_j = 20;
        }
        else
        {
            var fancy_a = 1016;
            var fancy_b = 655;
            var fancy_c = "ishopbg";
            var fancy_d = "16px";
            var fancy_e = "7px";
            var fancy_f = "16px";
            var fancy_g = 1032;
            var fancy_h = 690;
            var fancy_i = 8;
            var fancy_j = 28;
        }
        var fancybox_css = {
            'outer': {'background': null},
            'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
        };
        $('a.itemshop').fancybox({
            'autoDimensions': false,
            'width': fancy_a,
            'height': fancy_b,
            'padding': 0,
            'scrolling': 'yes',
            'overlayColor': '#000',
            'overlayOpacity': 0.8,
            'onStart': function () {
                fancybox_css.outer.background = $('#fancybox-outer').css('background');
                fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                fancybox_css.close.height = $('#fancybox-close').css('height');
                fancybox_css.close.right = $('#fancybox-close').css('right');
                fancybox_css.close.top = $('#fancybox-close').css('top');
                fancybox_css.close.width = $('#fancybox-close').css('width');
                $('#fancybox-outer').css({'background': 'transparent url("<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/static/images/ishopbg.png") center center no-repeat'});
                $('#fancybox-close').css({
                    'background-image': 'none',
                    'cursor': 'pointer',
                    'height': fancy_d,
                    'right': '3px',
                    'top': fancy_e,
                    'width': fancy_f
                });
            },
            'onComplete': function () {
                $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
            },
            'onClosed': function () {
                if (null != fancybox_css.outer.background) {
                    $('#fancybox-outer').css('background', fancybox_css.outer.background);
                }
                if (null != fancybox_css.close.background_image) {
                    $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                }
                if (null != fancybox_css.close.height) {
                    $('#fancybox-close').css('height', fancybox_css.close.height);
                }
                if (null != fancybox_css.close.right) {
                    $('#fancybox-close').css('right', fancybox_css.close.right);
                }
                if (null != fancybox_css.close.top) {
                    $('#fancybox-close').css('top', fancybox_css.close.top);
                }
                if (null != fancybox_css.close.width) {
                    $('#fancybox-close').css('width', fancybox_css.close.width);
                }
            }
        });
    });
</script>
<script>
    $(window).scroll(function(){
        if ($(this).scrollTop() > 100)
            $("#yukari").fadeIn(500);
        else
            $("#yukari").fadeOut(500);
    });
    $(document).ready(function(){
        $("#yukari").click(function(){
            $("html, body").animate({ scrollTop: "0" }, 1000);
            return false;
        });
    });
</script>
<script>
    $(document).ready(function () {
        if ($(window).width() < 540) {
            document.getElementById('fb').style.display = 'none';
        }else{
            setTimeout(function () {
                $('#fbLoading').fadeOut(function () {
                    $('#fbContent').fadeIn(function () {

                    })
                });
            }, 3500);
        }
    });
</script>
<script>
    function textonly(e,id){
        var code;
        if (!e) var e = window.event;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
//alert('Character was ' + character);
        //alert(code);
        //if (code == 8) return true;
        var AllowRegex  = /^[\ba-zA-Z0-9\s-]$/;
        if (AllowRegex.test(character)){
            return true;
        }else{
            $(id).notify(
                "Sadece harf ve rakam",
                { position:"right" }
            );
            return false;
        }
    }
    $('#login').change(function () {
        var url = "register/login";
        var data = $(this).val();
        $.post(url,{data:data},function (result) {
            if(result.result == true){
                document.getElementById('loginNo').style.display = "none";
                document.getElementById('loginOk').style.display = "";
            }else if(result.result == false){
                document.getElementById('loginOk').style.display = "none";
                document.getElementById('loginNo').style.display = "";
                $('#login').notify(
                    "Kullanıcı adı kullanımda !",
                    { position:"right" }
                );
            }
        },"json");
    });
    $('#pass2').change(function () {
        var pass = $('#pass').val();
        var pass2 = $(this).val();
        if(pass != pass2){
            document.getElementById('passOk').style.display = "none";
            document.getElementById('passNo').style.display = "";
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }else{
            document.getElementById('passNo').style.display = "none";
            document.getElementById('passOk').style.display = "";
        }
    });
    $('#pass').change(function () {
        var pass = $('#pass2').val();
        var pass2 = $(this).val();
        if(pass != ''){
            if(pass != pass2){
                document.getElementById('passOk').style.display = "none";
                document.getElementById('passNo').style.display = "";
                $('#pass2').notify(
                    "Şifreler uyuşmuyor !",
                    { position:"right" }
                );
            }else{
                document.getElementById('passNo').style.display = "none";
                document.getElementById('passOk').style.display = "";
            }
        }
    });
    function textonly2(e,id){
        var code;
        if (!e) var e = window.event;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
//alert('Character was ' + character);
        //alert(code);
        //if (code == 8) return true;
        var AllowRegex  = /^[\ba-z-A-ZÇİĞÖŞÜçığöşü\s-]$/;
        if (AllowRegex.test(character)){
            return true;
        }else{
            $(id).notify(
                "Sadece harf !",
                { position:"right" }
            );
            return false;
        }
    }
    function numberonly(e,id){
        var code;
        if (!e) var e = window.event;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
//alert('Character was ' + character);
        //alert(code);
        //if (code == 8) return true;
        var AllowRegex  = /^[\b0-9\s-]$/;
        if (AllowRegex.test(character)){
            return true;
        }else{
            $(id).notify(
                "Sadece rakam !",
                { position:"right" }
            );
            return false;
        }
    }
    $('#question').mouseover(function () {
        document.getElementById('question2').style.display="";
    });
    $('#question').mouseout(function () {
        document.getElementById('question2').style.display="none";
    });
</script>
