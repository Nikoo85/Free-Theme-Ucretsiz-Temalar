<?php
/* 
------------------
Language: ingilizce
------------------
*/

$lang = array(
	'anasayfa' => 'Homepage',
	'indir' => 'Download',
	'siralama' => 'Raning',
	'market' => 'Shop',
	'forum' => 'Forms',
	'kaydol' => 'Register'
);
?>
