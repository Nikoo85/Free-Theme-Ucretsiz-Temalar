<?php
/* 
------------------
Language: Almanca
------------------
*/

$lang = array(
	'anasayfa' => 'Zuhause',
	'indir' => 'Herunterladen',
	'siralama' => 'Rang',
	'market' => 'Märkte',
	'forum' => 'Forms',
	'kaydol' => 'registrieren'
);
?>
