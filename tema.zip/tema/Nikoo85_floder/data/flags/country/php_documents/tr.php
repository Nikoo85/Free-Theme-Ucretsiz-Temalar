<?php
/* 
------------------
Language: CANIM TÜRKÇEM
------------------
*/

$lang = array(
	'anasayfa' => 'Anasayfa',
	'indir' => 'İndir',
	'siralama' => 'Sıralama',
	'market' => 'Market',
	'forum' => 'Forum',
	'kaydol' => 'Kayıt Ol'
);
?>
