<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Hemen Yükle</div>
 
  <?php
$i = 0; 

  foreach($pack_sec as $pack)

 $i++;
if($i == 0) {
	echo ' <style>
.hata-err {
    color: #ffe991;
    background-color: #c00;
    border-color: #fb6767;
}
.hata {
    position: relative;
    padding: .75rem 1.25rem;
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 1px solid #153348;
    border-radius: 0;
    background-color: #102a3d;
    font-weight: 600;
}
</style>

<div class="hata-err mb-0 animated shake"><div style="background-color:red;"  class="hata"  >İNDİRME LİNKLERİ EKLENMEDİ !</div></div>';
}else{
  $linkler = explode(',' ,$pack["linkler"]);
  ?>    
<div class="panel-body">
				                <div class="modal fade" id="Indir_0" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <h4 class="modal-title" id="myModalLabel">İndirme Sözleşmesi</h4>
                            </div>
                            <div class="modal-body">
								<textarea class="sozlesme_txt" readonly="">Oyunumuza kayıt olmuş her oyuncu aşağıda yazılan tüm kuralları kabul etmiş sayılır, Metin2Jax yönetimi bu kurallarda değişiklik yapabilir veya yeni kural ekliyebilir oyuncularımızın hepsi bu kural değişikliklerini takip etmekle yükümlüdür.

Aşağıda yazan kurallara ek olarak TÜRK CEZA KANUNU’nun tüm maddeleri kurallarımıza dahildir.

1.0 ) Sohbet Kuralları

1.1 ) Oyunumuzdaki sohbet eden oyuncuların bütün mesajları kayıt edilmektedir,  bu mesajlar yöneticiler tarafından ön kontrole tabi tutulmamaktadır. Bu yüzden yazılan mesajlar yazan kişinin sorumluluğundadır. Oyun yönetimi kurallara aykırı bir mesaj tespit ettiğinde hesabınızı kapatma yetkisine sahiptir. Uygulanacak ceza ve süresi  oyun yöneticisinin insiyatifindedir.

1.2 ) Herhangi bir oyuncunun dinine , ırkına , mezhebine , diline veya herhangi bir nedenle hakaret eden/dalga geçen oyuncular oyun yönetimi tarafından oyundan uzaklaştırılır.
1.3 ) Bağırmak veya Genel sohbet alanından aynı mesajları hızlı bir şekilde tekrar tekrar yazmak(Spam/Flood) ve diğer oyuncuları rahatsız etmek hesabınızın kapatılmasına sebep olur.

1.4 ) Oyun içerisindeki bütün sohbet protekollerinden başka oyun veya sitelerin reklamının yapılması oyundan uzaklaştırılmasına sebep olur.
1.5 ) Oyun içerisindeki bütün sohbet protekollerinden ard arda mesaj atmak (flood yapmak &amp; spamlamak) hesabınızın süresiz olarak kapatılmasına neden olmaktadır.

2.0 ) Oyuncu Kuralları
2.1 ) Herhangi bir oyuncunun kişisel bilgilerini (Telefon numarası , Resim vb.) üçüncü şahıslarla paylaşmak suçtur. Bu tür durumlarda oyun yönetimi tarafından hesapları kapatılacaktır , ancak yaşanabilecek herhangi bir yasal problemden oyun yönetimi sorumlu değildir , Oyun yönetimi kişisel bilgileri paylaşan (suçlu olan) kişinin tüm verilerini (İp adresi, Ödeme kayıtları , Tahmini lokasyon bilgisi) talep eden yetkili kişi veya kişilerle paylaşmaya hazırdır.
2.2 ) Herhangi bir oyuncu oyunda elde ettiği veya tl karşılığında nesne marketten almış olduğu eşyaları herhangi bir şekilde TL karşılığında satamaz, bu durum görevliler tarafından fark edilirse hesabınızın kapatılmasına sebep olur.
2.3 ) Oyuncuları tehdit etmek, tehdit ile kazanç sağlamak hesabınızın kapatılmasına sebep olur.
2.4 ) Oyuncularla dalga geçmek, oyuncunun oyunu rahatça oynamasına engel olmak hesabınızın kapatılmasına sebep olur.
2.5 ) Oyun içerisinde hile veya oyun hatası ile haksız kazanç elde etmek veya diğer oyuncuların hakkını gasp etmek hesabınızın kapatılmasına sebep olur.
2.6 ) Bir oyuncunun itemlerini almak veya hesabına izinsiz girmek hesabınızın kapatılmasına sebep olur. Oyun yönetimi bu durumda zarara uğrayan oyuncuya item iadesi veya hesap iadesi kesinlikle söz konusu değildir.
2.7 ) Suçu kesinleşmiş oyuncuyu savunmak, bağırmak veya genel sohbet alanından bu oyuncuyla ilgili sıklıkla yazılar yazmak hesabınızın kapatılmasına sebep olur. Ceza işlemi görevli kişinin insiyatifindedir.
2.8 ) Ceza alan oyuncuların kendilerini savunabileceği alan destek sistemidir oyun içerisinde bu konu hakkında cevap veya yardım alamazsınız. Bu konuda ısrarlı olduğunuz takdirde savunma hakkınız elinizden alınabilir ve tüm hesaplarınız kapatılır.
2.9 ) Hesabımı kimse kapatamaz, Ben oyuna para yatırdım vb. yaklaşımlarda bulunup kendilerini diğer oyunculardan üstün gören oyuncuların hesapları şikayet edildiği taktirde kapatılmaktadır. Oyunumuzu oynayan tüm oyuncularımız eşittir ve oyun yönetimi oyuncuların bu tip yaklaşımlarına izin vermemektedir.
3.0 ) Oyun yönetimindeki kişileri tanıdığını iddia ederek bir oyuncuyu oyunu oynayamayacak kadar rahatsız etmek hesabınızın kapatılmasına sebep olmaktadır.

3.1 ) Herhangi bir oyuncunun kişisel yazışmalarını, konuşmada bulunan kişilerin tamamının izni olmaksızın üçüncü şahıslarla paylaşmak hesabınızın kapatılmasına sebep olur, bu kurala Oyun yönetiminin yazdıklarıda dahildir.
3.2 ) Hile dağıtımı, Hile kullanımına yardımcı olmak hesabınızın kapatılmasına sebep olur. Bu olaya lonca üyelerinin %50 sinin karıştığı tespit edilirse lonca dağıtılır ve loncadaki tüm oyuncuların hesapları kapatılır.
3.3 ) Oyun açığının dağıtılması, Oyun açığının kullanılmasına yardımcı olmak hesabınızın kapatılmasına sebep olur. Bu olaya lonca üyelerinin %50 sinin karıştığı tespit edilirse lonca dağıtılır ve loncadaki tüm oyuncuların hesapları kapatılır.
3.4 ) Siyaset içeren oyuncu isimlerinin kullanımı yasaktır, gerekli görüldüğünde oyuncunun başka bir isime taşınması talep edilebilir. Bu talebe uymayan oyuncuların hesapları  kapatılır.

3.5 ) Kural ihlali her ne olursa olsun oyuncunun tüm hesapları(IP Taraması) sonucu kapatılabilir.
4.0 ) Lonca Kuralları

4.1 ) Siyaset içeren lonca isimlerinin kullanımı yasaktır, gerekli görüldüğünde loncanın başka bir isime taşınması talep edilebilir. Bu talebe uymayan loncalar kapatılır.
4.2 ) Oyun görevlisi lonca liderinden loncada bulunan bir oyuncu ile ilgili bazı bilgiler talep edebilir, lonca lideri bu bilgileri eksiksiz ve doğru bir şekilde vermekle görevlidir. Yanlış yönlendirme veya hatalı bilgilendirme yapan lonca liderinin hesapları kapatılır.
4.3 ) Lonca üyelerinin toplu bir şekilde oyun yönetimine hakaret etmesi veya oyun kurallarını hiçe sayması tüm lonca üyelerinin oyundan uzaklaştırılmasına sebep olur.
4.4 ) Lonca savaşlarında haksız puan elde etmek veya sıralama yükseltmek yasaktır. Lonca dağıtılır ve bu işe karışan tüm oyuncuların hesabı kapatılabilir.
4.5 ) Lonca turnuvularında veya özel lonca etkinliklerinde etkinliği düzenleyen yöneticinin belirtmiş olduğu tüm kurallara uyulmalıdır. Etkinlik yöneticisi kurallara uymadığını düşündüğü loncaları turnuvadan çıkartabilir.
5.0 ) Genel Oyun Kuralları

5.1 )  Oyunu indirmek, oyuna kayıt olmak ve oynamak tamamen ücretsizdir.
5.2 )  13-18 yaş arasındaki oyuncu adaylarının ebeveyn isteği dışında sunuculara kayıt olmaları yasaktır.
5.3 ) Nesne marketten alınan herhangi bir eşyanın hesap kapatıldıktan sonra veya kullanılmaya başladıktan sonra geri iadesi mümkün değildir.
5.4 ) 13 yaş altındaki oyuncu adaylarının sunuculara kayıt olmaları yasaktır , kayıt olmaları durumunda hesapları tespit edildiğinde kapatılır ve veli izni olana dek açılmayacaktır.
5.5 ) Oyun yönetimi sizlerin hesaplarını ve şifrelerini hiç kimseyle paylaşmaz. Bilgileriniz güvenli bir şekilde saklanmaktadır, Lütfen oyun içerisinde veya farklı yerde Metin2Jax ye ait olmayan sitelere girip bilgileriniz vermeyin, Soyulma durumlarında yetkililer hiçbir şekilde eşya iadesi yapmayacaklardır, Hesabınızın çalınması durumunda yöneticilerin durum değerlendirmesine bağlı olarak hesap geri verilebilir.
5.6 ) Oyun Yönetimi Kendisinin görüp banladığı kişilerde ss ( Kanıt gösterme ve belirtme ) yükümlülüğü yoktur!
5.7 ) Oyun yönetimi istediği zaman istediği tarihte, tüm karakter ve oyunu yok etme hakkına sahiptir. Bu durumda kimseye hiçbir şekilde yatırdığı para veya oyun itemleri geri iade edilmeyecektir.Oyuncu &amp; Kullanıcı Yasal veya yasal olmayan yollarla hak talebinde bulanamayacaktır.
5.8 ) Oyun verileri 6 saatte bir yedeklenmektedir oyunda herhangi bir sorunla karşılaşıldığı zaman en kısa süre önceki yedek yüklenecektir ve olası item ve hesap verileri kaybından yönetim ekibi sorumlu tutulamaz.</textarea>
                            </div>
                            <div class="modal-footer">

                                <button type="button" class="btn btn-default" data-dismiss="modal">İptal</button>
								<?php $i = 0; foreach($linkler as $link){ $i++;?>
                                <a href="<?=$link;?>" target="_new" class="btn btn-giris">Kabul et ve indir</a>
								<?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
				                <table class="table table-striped table-hover">

                    <tbody>
					                    <tr>
                        <td><?=$pack["pack"];?> <br><small>Boyut : <?=$pack["boyut"];?></small></td>
                        <td><img src="./data/flags/dosyaco.png" alt="Demo" width="70px;" style=" margin-top: 12px;"></td>
                        <td style="vertical-align:middle;text-align:right;"><button class="btn btn-giris" data-toggle="modal" data-target="#Indir_0"><i class="glyphicon glyphicon-download-alt"></i> &nbsp; Oyunu indir</button></td>
                    </tr>
					
                    </tbody>
                </table>
            </div>
			
	<?php 
}


  ?>  

                                </div>
                            </div>
                       
						
<div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Sistem Gereksinimleri</div>
								                                
<div class="panel-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <td><b>Bileşen Adı</b></td>
                        <td><b>En Düşük Gereksinim</b></td>
                        <td><b>Orta Derece Gereksinim</b></td>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                        <td>Boş Alan (HDD)</td>
                        <td>2GB</td>
                        <td>3GB ve üzeri</td>
                    </tr>
                    <tr>
                        <td>Bellek (RAM)</td>
                        <td>2GB</td>
                        <td>4GB ve üzeri</td>
                    </tr>
                    <tr>
                        <td>İşlemci (CPU)</td>
                        <td>Pentium 3 , 1GHz</td>
                        <td>İntel core i3 ve üzeri</td>
                    </tr>
                    <tr>
                        <td>Ekran Kartı (GPU)</td>
                        <td>512Mb</td>
                        <td>1Gb ve üzeri</td>
                    </tr>
                    <tr>
                        <td>İşletim Sistemi</td>
                        <td>Win XP</td>
                        <td>Win 7 ve üzeri</td>
                    </tr>
                    <tr>
                        <td>DirectX</td>
                        <td>9</td>
                        <td>9 ve üzeri</td>
                    </tr>
                    </tbody>
                </table>
            
                                </div>
                            </div>
                        </div>