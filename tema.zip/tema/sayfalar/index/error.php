<body><style>@font-face {
    font-family: DKLiquidEmbrace;
    src: url("/fonts/DK Liquid Embrace.ttf")
}

@font-face {
    font-family: Edo SZ;
    src: url(/fonts/edosz.ttf)
}

@font-face {
    font-family: Elementary Gothic;
    src: url(/fonts/Elementary_Gothic.ttf)
}

@font-face {
    font-family: Elementary Gothic Scaled;
    src: url(/fonts/Elementary_Gothic_Scaled.ttf)
}

@font-face {
    font-family: Raleway;
    src: url(/fonts/Raleway.ttf)
}

::-webkit-input-placeholder {
    color: #633f33
}

:-moz-placeholder,
::-moz-placeholder {
    color: #633f33;
    opacity: 1
}

:-ms-input-placeholder {
    color: #633f33
}

body {
    background: #000;
    margin: 0;
    padding: 0;
    font-size: 12px;
}

body.no-scroll {
    overflow: hidden
}

body,
button,
html {
    padding: 0;
    margin: 0;
    font-family: 'Raleway', sans-serif;
    font-size: 13px;
    font-weight: 100;
    line-height: 1.2
}

* {
    margin: 0;
    padding: 0;
    vertical-align: bottom;
}

a {
    color: #794635;
    text-decoration: none;
}

a:hover {
    color: white;
}

a:focus,
a:hover {
    text-decoration: none
}

a:focus {
    outline: thin dotted;
    outline: 5px auto -webkit-focus-ring-color;
    outline-offset: -2px
}

b,
strong {
    font-weight: bolder;
}

.islemSonucNa {
    color: blue;
    font-weight: bold;
}

.islemSonucOk {
    color: green;
    font-weight: bold;
}

.islemSonucNo {
    color: brown;
    font-weight: bold;
}

#divSohbetCerceve {
    position: relative;
    background-image: url('/images/sohbet_bg.jpg');
    background-repeat: no-repeat;
    width: 540px;
    height: 228px;
    margin: auto;
    text-align: center;
    padding: 43px 0 0 0;
}

#divSohbet {
    float: left;
    text-align: left;
    width: 523px;
    height: 175px;
    margin: 0 0 0 0;
}

.sohbetSatir {
    float: left;
    width: 485px;
    height: 20px;
    line-height: 20px;
    margin: 0 0 0 10px;
    overflow: hidden;
    font-family: string 'Tahoma';
    font-size: 11px;
    opacity: 1;
}

#toolTip {
    display: none;
    position: absolute;
    z-index: 200;
    font-family: 'Tahoma,Verdana,Segoe,sans-serif';
    font-size: 11px;
}

#toltip {
    position: relative;
    background-image: url('/images/thinboard_orta.png');
    width: 200px;
    min-height: 100px;
    margin: 15px 100px;
}

.toptipTopLeft {
    position: absolute;
    top: 0;
    left: 0;
    background-image: url('/images/thinboard_corner_lefttop.png');
    width: 16px;
    height: 16px;
}

.toptipTopRight {
    position: absolute;
    top: 0;
    right: 0;
    background-image: url('/images/thinboard_corner_righttop.png');
    width: 16px;
    height: 16px;
}

.toptipButtomLeft {
    position: absolute;
    bottom: 0;
    left: 0;
    background-image: url('/images/thinboard_corner_leftbottom.png');
    width: 16px;
    height: 16px;
}

.toptipButtomRight {
    position: absolute;
    bottom: 0;
    right: 0;
    background-image: url('/images/thinboard_corner_rightbottom.png');
    width: 16px;
    height: 16px;
}

.toptipLeft {
    position: absolute;
    top: 0;
    left: 0;
    background-image: url('/images/thinboard_line_left.png');
    width: 2px;
    height: 100%;
    background-repeat: repeat-y;
}

.toptipRight {
    position: absolute;
    top: 0;
    right: 0;
    background-image: url('/images/thinboard_line_right.png');
    width: 2px;
    height: 100%;
    background-repeat: repeat-y;
}

.toptipTop {
    position: absolute;
    top: 0;
    left: 0;
    background-image: url('/images/thinboard_line_top.png');
    width: 200px;
    height: 2px;
    background-repeat: repeat-x;
}

.toptipButtom {
    position: absolute;
    bottom: 0;
    left: 0;
    background-image: url('/images/thinboard_line_bottom.png');
    width: 200px;
    height: 2px;
    background-repeat: repeat-x;
}

.tolTipName {
    clear: both;
    margin: auto;
    height: 40px;
    line-height: 40px;
    color: beige;
}

.tolTipIcon {
    clear: both;
    margin: auto;
    margin: 0 0 10px 0;
}

.tolTipDesc {
    clear: both;
    margin: auto;
    width: 170px;
    line-height: 18px;
    overflow: hidden;
    color: #C1C1C1;
}

.tolTipSatirArasi {
    clear: both;
    width: 170px;
    min-height: 5px;
    line-height: 5px;
}

.tolTipEfsun {
    clear: both;
    margin: auto;
    color: #B0DFB4;
    line-height: 18px;
}

.tolTipEfsun6 {
    clear: both;
    margin: auto;
    color: #BEB47D;
    line-height: 18px;
}

.tolTipEfsunAttr {
    clear: both;
    margin: auto;
    color: #89B88D;
    line-height: 18px;
}

.tolTipEfsunAttrx {
    clear: both;
    margin: auto;
    color: #E57875;
    line-height: 18px;
}

.tolTipEfsunBlur {
    clear: both;
    margin: auto;
    color: #B0DFB4;
    line-height: 18px;
    filter: blur(3px);
}

.tolTipKalanSure {
    clear: both;
    margin: auto;
    color: #C1C1C1;
    line-height: 18px;
    margin: 5px 0 0 0;
}

.tolTipYansitma0 {
    clear: both;
    margin: auto;
    color: #8BBDFF;
    line-height: 18px;
    margin: 5px 0 0 0;
}

.tolTipYansitma1 {
    clear: both;
    margin: auto;
    color: #BCE55C;
    line-height: 18px;
}

.tolTipKusakEmis {
    clear: both;
    margin: auto;
    color: #BEB47D;
    line-height: 18px;
}

.tolTipName,
.tolTipDesc,
.tolTipEfsun,
.tolTipEfsunAttr,
.tolTipEfsunAttrx,
.tolTipKalanSure,
.tolTipYansitma0,
.tolTipYansitma1,
.tolTipKusakEmis {
    text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
}

#divSohbetSaat {
    position: absolute;
    right: 45px;
    margin: -38px 0 0 0;
    color: beige;
    font-size: 11px;
}

.sohbetImgBayrak {
    height: 1em;
    vertical-align: middle;
}

#divYapi {
    width: 1157px;
    margin: auto;
    min-height: 500px;
    background-image: url(/images/S07/bg-top.jpg), url(/images/S07/bg-bottom.jpg);
    background-repeat: no-repeat, no-repeat;
    background-position: center top, center bottom;
    position: relative;
    padding-top: 50px;
}

#divYapiDisUst {
    height: 463px;
    background: url(/images/ozel/s07_bg.jpg) center no-repeat;
    position: relative;
}

#divYapiDisAlt {
    display: block;
}

#divYapiUst {
    display: block;
}

#divYapiAlt {
    display: block;
}

#divYapiOrta {
    float: left;
    width: 600px;
}

#divYapiSol {
    float: left;
    margin-top: -114px;
    width: 278px;
    z-index: 20;
    margin-bottom: 198px;
}

#divYapiSag {
    float: right;
    margin-top: -114px;
    width: 278px;
    z-index: 20;
}

#divYapiDisUst .logo {
    position: absolute;
    bottom: 0;
    width: auto;
    width: 100%;
    height: 210px;
    background: url('/images/ozel/logo.png') no-repeat;
    background-position: center;
    background-size: auto 210px;
}

#divYapiDisUst .logo-swf {
    width: 1157px;
    height: 300px;
    position: absolute;
    top: 200px;
    bottom: 0;
    left: 50%;
    margin-left: -600px;
}

#divYapiDisUst .container {
    position: relative;
    width: 1156px;
    margin: auto;
    z-index: 1;
}

#divYapiDisUst .server {
    float: left;
    height: 230px;
    width: 116px;
    background: url(/images/S07/bg-server.png) center no-repeat;
    text-align: center;
}

#divYapiDisUst .server div {
    opacity: .6;
    height: 100%;
}

#divYapiDisUst .server div:hover {
    opacity: 1
}

#divYapiDisUst .server div img {
    margin-top: 105px;
}

#divYapiDisUst .bDownload {
    float: right;
    margin: 80px -80px 0 0;
}

#divYapiDisUst {
    position: relative
}

button::-moz-focus-inner,
[type="button"]::-moz-focus-inner,
[type="reset"]::-moz-focus-inner,
[type="submit"]::-moz-focus-inner {
    border-style: none;
    padding: 0;
}

.btn-login {
    margin: 0 -14px 0;
    background: url(/images/S07/btnBig_normal.png) center -41px no-repeat;
    background-size: auto auto;
    border: none;
    width: 239px;
    height: 63px;
    cursor: pointer;
    background-size: 230px;
}

.btn-login:hover {
    background: url(/images/S07/btnBig_hover.png) center -41px no-repeat, url(/images/S07/btnBig_normal.png) center 0 no-repeat;
    background-size: 230px;
}

.btn-login > span {
    margin: 0;
    text-align: center;
    font-size: 31px;
    font-family: 'Edo SZ';
    color: #ce9639;
    font-variant: small-caps;
    text-shadow: 0.585px 1.913px 1px rgb(0, 0, 0);
}

.panel {
    margin-bottom: -33px
}

.panel:after {
    content: ' ';
    background: url(/images/S07/bg-panel-bottom.png) center no-repeat;
    height: 69px;
    display: block
}

.panel-header {
    background: url('/images/S07/pnl_hdr.png') center no-repeat;
    width: 278px;
    height: 125px;
    position: relative
}

.panel-header-rank {
    background: url(/images/S07/bg-panel-header-rank.png) center no-repeat
}

.panel-header h2 {
    padding-top: 84px
}

.panel-header .close-panel {
    position: absolute;
    top: 71px;
    font-size: 38px;
    color: #bb7b3b;
    text-shadow: 3px 3.913px 3px #182704;
    left: 223px;
    cursor: pointer;
    opacity: .8;
    display: none
}

.panel-header .close-panel:hover {
    opacity: 1
}

.panel-content {
    background: url(/images/S07/bg-panel.png) center repeat-y;
    padding: 6px 31px 6px 34px;
}

.panel-inner {
    border: 1px solid #754a3d;
    border: 1px solid rgba(117, 74, 61, .3);
    border-radius: 10px;
    background-color: #000000;
    background-color: rgba(0, 0, 0, .4);
    margin: 5px 0;
    color: #704826;
    text-align: center;
}

ul.menu {
    text-align: center;
    padding: 0 23px;
    list-style-type: none;
    margin: 14px 0;
}

ul.menu li + li:before {
    content: ' ';
    display: block;
    background: url(/images/S07/ornament.png) center no-repeat;
    height: 35px
}

.menu a {
    display: block;
    border: 1px solid #674137;
    border: 1px solid rgba(103, 65, 55, .6);
    background-color: #170b04;
    opacity: .9;
    color: #633f33;
    font-weight: 700;
    text-shadow: 0 1px 3px #312726;
    padding: 7px 0;
}

.menu a:hover {
    box-shadow: inset 0 0 15px #703615;
    box-shadow: inset 0 0 15px rgba(112, 54, 21, .5);
    border-width: 2px;
    padding: 6px 0
}

.menu-helper {
    font-size: 11px;
    margin-top: 2px
}

.mobile-menu-item h2,
.panel-header h2 {
    margin: 0;
    text-align: center;
    font-size: 18px;
    font-family: "Edo SZ";
    color: #511d07;
    font-variant: small-caps;
    text-shadow: .585px 1.913px 1px rgba(214, 171, 102, .82);
}

.mobile-menu,
.panel-header .close-panel {
    display: block
}

.panel-login label {
    color: #704826;
    font-weight: 700;
    padding: 17px 0 11px;
    display: block;
}

.input input[type="password"],
.input input[type="text"],
.input input[type="email"] {
    display: block;
    border: 1px solid #432c12;
    border-radius: 10px;
    background-color: #150904;
    height: 35px;
    color: #704826;
    text-align: center;
    box-sizing: border-box;
    margin: auto;
}

.input-rich {
    position: relative
}

.input-rich input[type=password],
.input-rich input[type=text],
.main-inner form table {
    width: 100%
}

.input-rich:before {
    width: 42px;
    height: 46px;
    background: url(/images/S07/input-rich.png) center no-repeat;
    top: -5px;
    left: -20px
}

.input-rich:after,
.input-rich:before,
.main-panel:after {
    position: absolute;
    display: block;
    content: ' '
}


/* ReSharper disable once InvalidValue */

.input-rich:after {
    background: url(/images/S07/input-rich.png) center no-repeat;
    right: -20px;
    -moz-transform: scaleX(-1);
    -o-transform: scaleX(-1);
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
    filter: FlipH;
    -ms-filter: "FlipH";
    width: 42px;
    height: 46px;
    top: -5px
}

.rank-table {
    width: 100%;
    color: #4f4a45;
    font-size: 12px;
    font-weight: 700
}

.rank-table tbody tr:nth-of-type(1) {
    color: #766339
}

.rank-table tbody tr:nth-of-type(1) td:nth-child(2) {
    font-size: 13px
}

.rank-table tbody tr:nth-of-type(2) {
    color: #6f6a65
}

.rank-table tbody tr:nth-of-type(3) {
    color: #5a3d2a
}

.rank-table tr td:nth-child(2) {
    border-bottom: 1px solid #2e1e19;
    border-bottom: 1px solid rgba(46, 30, 25, .68);
    padding: 4px 0 3px
}

.rank-table tr td:nth-child(3) {
    font-size: 12px
}

.rank-table img {
    margin: -20px 0 -11px -15px
}

[class^="icon-"],
[class*=" icon-"] {
    font-family: 'icomoon';
    speak: none;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    min-width: 1em;
    display: inline-block;
    text-align: center;
    font-size: 16px;
    vertical-align: middle;
    position: relative;
    top: -1px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.player-table .position-left {
    padding-right: 3px
}

#divYapi .btn-begin {
    display: block;
    position: absolute;
    text-align: center;
    left: 0;
    right: 0;
    top: -5px;
    z-index: 1;
}

#divYapi .btn-begin div.bg,
#divYapi .btn-begin div.bg-hover {
    position: absolute;
    left: 0;
    right: 0;
    height: 89px;
    margin-left: auto;
    margin-right: auto;
}

#divYapi .btn-begin div.bg {
    background: url(/images/S07/btn-begin.png) center 0 no-repeat
}

#divYapi .btn-begin a {
    position: absolute;
    display: block;
    top: 25px;
    left: 50%;
    margin-left: -97px;
    z-index: 100
}

#divYapi .btn-begin a:hover + div.bg-hover {
    background: url(/images/S07/btn-begin.png) center -89px no-repeat
}

.panel-download .col-50 strong,
.panel-player .player-info strong,
.player-table .player-row strong {
    font-weight: 700
}

.main-header {
    margin: 0 64px 0 67px;
    background: url(/images/S07/bg-content-sn.png) center 0 no-repeat;
    height: 34px;
    position: relative;
    text-align: center;
    font-size: 25px;
    font-family: "Edo SZ";
    color: #511d07;
    font-variant: small-caps;
    text-shadow: .585px 1.913px 1px rgba(214, 171, 102, .82);
    z-index: 10
}

.main-header:after,
.main-header:before {
    position: absolute;
    display: block;
    top: 0;
    height: 48px;
    content: ' '
}

.main-header:before {
    left: -67px;
    background: url(/images/S07/bg-content-sn.png) left top no-repeat;
    width: 67px
}

.main-header:after {
    right: -64px;
    width: 64px;
    background: url(/images/S07/bg-content-sn.png) right top no-repeat
}

.main-content {
    padding: 15px 0 25px;
    position: relative;
    color: #5f2917;
    text-align: center
}

.main-content:after,
.main-content:before {
    position: absolute;
    display: block;
    top: 0;
    bottom: 0;
    width: 8px;
    content: ' ';
    z-index: 2
}

.main-content:before {
    left: 0;
    background: url(/images/S07/bg-content-we.png) left center repeat-y
}

.main-content:after {
    right: 0;
    background: url(/images/S07/bg-content-we.png) right center repeat-y
}

.main-content .btn:not(:last-child) {
    margin-bottom: 4px
}

.main-bottom {
    margin: 0 64px 0 67px;
    background: url(/images/S07/bg-content-sn.png) center bottom no-repeat;
    height: 12px;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 3
}

.main-bottom:after,
.main-bottom:before {
    position: absolute;
    display: block;
    bottom: 0;
    height: 47px;
    content: ' '
}

.main-bottom:before {
    left: -67px;
    background: url(/images/S07/bg-content-sn.png) left -48px no-repeat;
    width: 67px
}

.main-bottom:after {
    right: -64px;
    width: 64px;
    background: url(/images/S07/bg-content-sn.png) right -48px no-repeat
}

.main-text-bg {
    background: url(/images/S07/bg-main-center.png) top center repeat-y;
}

.main-text {
    max-width: 506px;
    margin: 0 auto;
    padding: 0 15px;
    text-align: center;
}

.main-text .bg-dark,
.main-text .bg-light {
    background-color: rgba(250, 250, 250, .09);
    padding: 7px;
    margin-bottom: 10px
}

.main-text .bg-dark {
    background-color: rgba(79, 53, 31, .278)
}

.main-text .bg-dark:after,
.main-text .bg-light:after {
    content: ' ';
    width: 100%;
    display: table
}

.main-inner-news .main-text .bg-dark,
.main-inner-news .main-text .bg-light {
    color: #261b18;
    font-weight: 700;
    text-align: left
}

.main-inner {
    position: relative;
    margin-bottom: 80px
}

.main-inner:after {
    position: absolute;
    display: block;
    right: 0;
    left: 0;
    bottom: -74px;
    height: 74px;
    content: ' ';
    background: url(/images/S07/bg-main-sn.png) top center repeat-y
}

.main-inner:before {
    position: absolute;
    display: block;
    right: 0;
    left: 0;
    bottom: -74px;
    height: 74px;
    content: ' ';
    background: url(/images/S07/bg-main-sn.png) top center repeat-y
}

.main-inner form table td:first-of-type {
    font-weight: 700
}

.main-inner form table td:last-of-type {
    text-align: left
}

.main-inner form input[type=number],
.main-inner form input[type=password],
.main-inner form input[type=text],
.main-inner form input[type=email] {
    border: 1px solid;
    color: #5f2917;
    background-color: #95714e;
    width: 100%;
    max-width: 193px;
    height: 30px;
    opacity: .9;
    text-align: center;
    box-sizing: border-box;
    box-shadow: inset 0 0 9px 2px rgba(50, 50, 50, .6);
    -webkit-border-image: -webkit-gradient(linear, 0 0, 0 100%, from(#915d4b), to(#6a2915)) 1 1;
    -webkit-border-image: -webkit-linear-gradient(#915d4b, #6a2915) 1 1;
    -moz-border-image: -moz-linear-gradient(#915d4b, #6a2915) 1 1;
    -o-border-image: -o-linear-gradient(#915d4b, #6a2915) 1 1;
    border-image: linear-gradient(to bottom, #915d4b, #6a2915) 1
}

.main-inner-news .main-text .bg-dark,
.main-inner-news .main-text .bg-light {
    color: #261b18;
    font-weight: 700;
    text-align: left
}

.main {
    margin: 72px 278px 0;
    padding-bottom: 225px;
}

.main-panel {
    position: relative;
    background: url(/images/S07/bg-content.png) repeat-x, url(/images/S07/bg-content.png) repeat-x;
    background-position: center -221px, center bottom -221px;
    width: 100%;
    margin-top: 75px
}

.main-panel:after {
    background: url(/images/S07/bg-content-top.png) center no-repeat;
    width: 100%;
    height: 49px;
    top: -49px
}

.content-title {
    background: url(/images/S07/bg-main-sn.png) center -74px no-repeat;
    height: 74px;
    font-size: 13px;
    color: #dcdcdc;
    font-weight: 700;
    text-align: center;
    text-transform: uppercase;
    padding: 32px 0 0;
    box-sizing: border-box;
}

.download table,
.logs table,
.ranking table {
    width: 100%;
    border-collapse: collapse
}

.download table tr:not(:last-child):not(:first-child) {
    background: rgba(132, 98, 66, .9);
    background: linear-gradient(to right, rgba(132, 98, 66, 0) 0%, rgba(132, 98, 66, .9) 15%, #846242 50%, rgba(132, 98, 66, .9) 85%, rgba(132, 98, 66, 0) 100%), 0 0;
    background-repeat: repeat, repeat;
    background-position-x: 0%, 0px;
    background-position-y: 0%, 0px;
    background-size: auto auto, auto auto;
    background-size: 100% 2px, 100% 100%;
    background-position: left bottom, left top;
    background-repeat: no-repeat;
}

.download table tr:nth-child(2) td {
    padding-top: 6px
}

.download table th {
    font-weight: 400;
    background-color: rgba(250, 250, 250, .09);
    padding: 12px 0
}

.download table td {
    padding: 5px 2px
}

.download table td:first-child,
.download table th:first-child {
    padding-left: 20px;
    text-align: left;
}

.download table td:last-child,
.download table th:last-child {
    padding-right: 20px
}

.download table td:first-child {
    font-size: 15px;
    color: #49332e;
    font-weight: 700
}

.download table td:nth-child(2) {
    color: #49332e
}

.download table tr:not(:last-child):not(:first-child) {
    background: rgba(132, 98, 66, .9);
    background: linear-gradient(to right, rgba(132, 98, 66, 0) 0%, rgba(132, 98, 66, .9) 15%, #846242 50%, rgba(132, 98, 66, .9) 85%, rgba(132, 98, 66, 0) 100%), 0 0;
    background-size: 100% 2px, 100% 100%;
    background-position: left bottom, left top;
    background-repeat: no-repeat
}

.download table tr:not(:first-child) td:not(:first-child) {
    background: rgba(132, 98, 66, .9);
    background: linear-gradient(to bottom, rgba(132, 98, 66, .9) 0%, rgba(132, 98, 66, .9) 100%), 0 0;
    background-size: 2px 100%, 100% 100%;
    background-position: left bottom, left top;
    background-repeat: no-repeat
}

.download table tr:nth-child(2) td:not(:first-child) {
    background: rgba(132, 98, 66, .9);
    background: linear-gradient(to bottom, rgba(132, 98, 66, 0) 10%, rgba(132, 98, 66, .9) 65%, #846242 100%), 0 0;
    background-size: 2px 100%, 100% 100%;
    background-position: left bottom, left top;
    background-repeat: no-repeat
}

.download table tr:last-child td:not(:first-child) {
    background: rgba(132, 98, 66, .9);
    background: linear-gradient(to bottom, #846242 0%, rgba(132, 98, 66, .9) 35%, rgba(132, 98, 66, 0) 90%), 0 0;
    background-size: 2px 100%, 100% 100%;
    background-position: left bottom, left top;
    background-repeat: no-repeat
}

.download .download-grey,
.download .download-red {
    display: block;
    width: 35px;
    height: 35px;
    margin: 0 auto
}

.download .download-grey {
    background: url(/images/S07/img-download.png) 0 0
}

.download .download-red {
    background: url(/images/S07/img-download.png) 0 35px
}

.ranking table tr:first-child th:first-child {
    border-radius: 10px 0 0 10px;
}

.ranking table tr:first-child th:last-child {
    border-radius: 0 10px 10px 0
}

.ranking table tr:nth-child(2) td {
    padding-top: 6px
}

.ranking table tr:not(:last-child) td {
    padding: 6px 5px 5px;
    border-bottom: 1px solid #846242
}

.ranking table th {
    text-align: center !important;
}

.ranking table td a {
    font-family: 'Lato', sans-serif;
    color: #5b3924;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis
}

.player-guild-table table td,
th {
    border-bottom: .1rem solid #846242;
    padding: .8rem;
    text-align: left;
}

.logs table td,
.ranking table td {
    padding: 4px
}

.label {
    display: inline;
    padding: .2em .6em .3em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: .25em;
    border: 1px solid;
    border-top-color: currentcolor;
    border-right-color: currentcolor;
    border-bottom-color: currentcolor;
    border-left-color: currentcolor;
}

.label-green {
    border-color: #427521;
    background-color: #298223;
}

.label-draw {
    border-color: #776e82;
    background-color: #435042;
}

.label-red {
    border-color: #881010;
    background-color: #770d0d;
}

.panel-download {}

.panel-download h3 {
    margin: 10px 0 15px;
}

.panel-download .col-50 {
    text-align: left;
    padding-left: 10px;
}

.panel-download .col-50 strong,
.panel-player .player-info strong,
.player-table .player-row strong {
    font-weight: 700
}

.col-50 {
    float: left;
    width: 50%;
    box-sizing: border-box;
}

#divYapiDisAlt {
    height: 91px;
    background: url(/images/S07/bg-footer.jpg) center no-repeat;
    position: relative;
    text-align: center;
    font-size: 11px;
    color: #5a5a5a
}

#divYapiDisAlt:after {
    content: ' ';
    position: absolute;
    left: 0;
    right: 0;
    top: -44px;
    height: 66px
}

#divYapiDisAlt .footer-content,
.footer-link {
    font-family: 'Lato', sans-serif;
    color: #8a6b2f
}

#divYapiDisAlt .footer-content,
#footer-links {
    font-size: 11px;
    text-align: center;
    margin-bottom: 20px
}

#divYapiDisAlt .footer-content {
    padding-top: 37px
}

#footer-links {
    font-family: Arial
}

.footer-link {
    padding-right: 45px;
    display: inline-block;
    vertical-align: middle;
    text-transform: uppercase;
}

.btn {
    display: block;
    background-color: #180c05;
    background: url(/images/S07/btn.png) no-repeat;
    color: #ad8865;
    text-decoration: none;
    opacity: .9;
    text-align: center;
    border: none;
    cursor: pointer;
    width: 100%;
    max-width: 213px;
    height: 26px;
    line-height: 1.8;
    margin: 0 auto
}

.btn-news {
    font-family: 'Raleway', sans-serif;
    font-size: 12px;
    margin-bottom: 5px;
    max-width: 105px;
    height: 21px;
}

.btn:hover {
    background: url(/images/S07/btn.png) 0 -26px no-repeat
}

#iFrameAna {
    border: 0;
    min-width: 100%;
    min-height: 550px;
}

.alert-box {
    border-radius: 10px;
    text-shadow: none;
    font-size: 12px;
    width: 95%;
    padding: 8px;
    text-align: center;
}

.info {
    background: #000000;
    background: rgba(0, 0, 0, 0.4);
    border: 1px solid #666;
    color: #ccc;
}

.container .pagination {
    margin: 5px 0;
    background-image: url(/images/S01/bg_seffaf.png);
    text-align: center
}


/* ReSharper disable once InvalidValue */

.pagination {
    padding: 8px;
    -ms-background-clip: padding-box;
    background-clip: padding-box;
    border: 1px solid;
    border-color: #070809 #0d0e0f #131517;
    border-color: rgba(0, 0, 0, 0.8) rgba(0, 0, 0, 0.65) rgba(0, 0, 0, 0.5);
    -ms-border-radius: 3px;
    border-radius: 3px;
    display: inline-block;
    vertical-align: baseline;
    zoom: 1;
    *display: inline;
    *vertical-align: auto;
    background-image: -webkit-linear-gradient(top, rgba(0, 0, 0, 0.12), rgba(0, 0, 0, 0));
    background-image: -moz-linear-gradient(top, rgba(0, 0, 0, 0.12), rgba(0, 0, 0, 0));
    background-image: -o-linear-gradient(top, rgba(0, 0, 0, 0.12), rgba(0, 0, 0, 0));
    background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.12), rgba(0, 0, 0, 0));
    -webkit-box-shadow: 0 1px #fff;
    -webkit-box-shadow: 0 1px rgba(255, 255, 255, 0.05);
    -ms-box-shadow: 0 1px #fff;
    -ms-box-shadow: 0 1px rgba(255, 255, 255, 0.05);
    box-shadow: 0 1px #fff;
    box-shadow: 0 1px rgba(255, 255, 255, 0.05);
    margin: auto
}

.pagination > a,
.pagination > span {
    float: left;
    margin-left: 5px;
    padding: 0 6px;
    -moz-min-width: 10px;
    -ms-min-width: 10px;
    -o-min-width: 10px;
    -webkit-min-width: 10px;
    min-width: 10px;
    line-height: 20px;
    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    font-size: 10px;
    font-weight: 500;
    color: #d4d4d4;
    text-align: center;
    text-decoration: none;
    border: 1px solid #000;
    -ms-border-radius: 3px;
    border-radius: 3px
}

.pagination:first-child {
    margin-left: 0
}

.pagination > a {
    text-decoration: none;
    -ms-text-shadow: 0 1px #000;
    text-shadow: 0 1px #000;
    -ms-background-clip: padding-box;
    background-clip: padding-box;
    border-color: #000;
    border-color: rgba(0, 0, 0, 0.9);
    background-image: -webkit-linear-gradient(top, rgba(255, 255, 255, 0.04), rgba(255, 255, 255, 0));
    background-image: -moz-linear-gradient(top, rgba(255, 255, 255, 0.04), rgba(255, 255, 255, 0));
    background-image: -o-linear-gradient(top, rgba(255, 255, 255, 0.04), rgba(255, 255, 255, 0));
    background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0.04), rgba(255, 255, 255, 0));
    -webkit-box-shadow: inset 0 0 0 1px #ffffff, inset 0 1px #ffffff, inset 0 -1px #000000, 0 1px 1px #000;
    -webkit-box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.04), inset 0 1px rgba(255, 255, 255, 0.04), inset 0 -1px rgba(0, 0, 0, 0.15), 0 1px 1px rgba(0, 0, 0, 0.1);
    -ms-box-shadow: inset 0 0 0 1px #ffffff, inset 0 1px #ffffff, inset 0 -1px #000000, 0 1px 1px #000;
    -ms-box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.04), inset 0 1px rgba(255, 255, 255, 0.04), inset 0 -1px rgba(0, 0, 0, 0.15), 0 1px 1px rgba(0, 0, 0, 0.1);
    box-shadow: inset 0 0 0 1px #ffffff, inset 0 1px #ffffff, inset 0 -1px #000000, 0 1px 1px #000;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.04), inset 0 1px rgba(255, 255, 255, 0.04), inset 0 -1px rgba(0, 0, 0, 0.15), 0 1px 1px rgba(0, 0, 0, 0.1);
    -webkit-transition: .1s ease-out;
    -moz-transition: .1s ease-out;
    -o-transition: .1s ease-out;
    -ms-transition: .1s ease-out;
    transition: .1s ease-out
}

.pagination > a:hover {
    background-color: #333;
    background-color: rgba(255, 255, 255, 0.05)
}

.pagination > span,
.pagination > a:active {
    color: #eee;
    color: #b0d157;
    -ms-text-shadow: 0 -1px #000;
    text-shadow: 0 -1px #000;
    background: #1c1c1c;
    background: rgba(255, 255, 255, 0.01);
    border-color: #000;
    border-color: #000 rgba(0, 0, 0, 0.65) rgba(0, 0, 0, 0.6);
    -webkit-box-shadow: inset 0 1px #000000, inset 0 2px 2px #000000, 0 1px #fff;
    -webkit-box-shadow: inset 0 1px rgba(0, 0, 0, 0.05), inset 0 2px 2px rgba(0, 0, 0, 0.3), 0 1px rgba(255, 255, 255, 0.06);
    -ms-box-shadow: inset 0 1px #000000, inset 0 2px 2px #000000, 0 1px #fff;
    -ms-box-shadow: inset 0 1px rgba(0, 0, 0, 0.05), inset 0 2px 2px rgba(0, 0, 0, 0.3), 0 1px rgba(255, 255, 255, 0.06);
    box-shadow: inset 0 1px #000000, inset 0 2px 2px #000000, 0 1px #fff;
    box-shadow: inset 0 1px rgba(0, 0, 0, 0.05), inset 0 2px 2px rgba(0, 0, 0, 0.3), 0 1px rgba(255, 255, 255, 0.06)
}

.pagination .prev,
.pagination .next {
    font-family: Noteworthy, Arial, sans-serif;
    font-size: 14px
}

.pagination-blue {
    background-color: #000532;
    background-color: rgba(0, 5, 50, 0.1)
}

.pagination-blue > a {
    background-color: #aaf;
    background-color: rgba(170, 170, 255, 0.01)
}

.pagination-blue > a.hover {
    background-color: #7882ff;
    background-color: rgba(120, 130, 255, 0.08)
}

.main-inner table td:first-of-type {
    font-weight: 700;
}

.main-inner table td:last-of-type {
    text-align: left;
}

.main-inner input[type="number"],
.main-inner input[type="password"],
.main-inner input[type="text"],
.main-inner input[type="email"] {
    border: 1px solid;
    border-image-source: none;
    border-image-slice: 100%;
    border-image-width: 1;
    border-image-outset: 0;
    border-image-repeat: stretch stretch;
    color: #5f2917;
    background-color: #95714e;
    width: 100%;
    max-width: 193px;
    height: 30px;
    opacity: .9;
    text-align: center;
    box-sizing: border-box;
    box-shadow: inset 0 0 9px 2px rgba(50, 50, 50, .6);
    -webkit-border-image: -webkit-gradient(linear, 0 0, 0 100%, from(#915d4b), to(#6a2915)) 1 1;
    -webkit-border-image: -webkit-linear-gradient(#915d4b, #6a2915) 1 1;
    -moz-border-image: -moz-linear-gradient(#915d4b, #6a2915) 1 1;
    -o-border-image: -o-linear-gradient(#915d4b, #6a2915) 1 1;
    border-image: linear-gradient(to bottom, #915d4b, #6a2915) 1;
}

button,
input,
optgroup,
select,
textarea {
    font-family: sans-serif;
    font-size: 100%;
    line-height: 1.15;
    margin: 0;
}

.register-helper,
.register-input {
    display: block;
    margin: 10px;
}

.player-card h3 {
    margin: 10px 0 5px !important;
}

.player-card h3,
.player-informations h3 {
    margin: 10px 0 !important;
    font-weight: 700;
    text-align: center;
}

.player-img {
    width: 100px;
    padding: 10px;
    margin-bottom: 5%;
}

.player-table {
    background-color: rgba(250, 250, 250, .09);
    border: 1px solid rgba(103, 65, 55, .6);
    margin-bottom: 2%;
    text-align: left;
}

.player-table .player-row {
    background-color: rgba(167, 132, 99, .55);
    border-bottom: 1px solid rgba(103, 65, 55, .6);
    padding: 10px;
}

.player-table .position-left {
    padding-right: 3px;
}

.player-table .player-row-stats {
    width: 340px;
    height: 45px
}

.player-table .player-row-stats .row {
    width: 84px;
    height: 39px;
    display: inline-block;
    float: left;
    padding-top: 7px;
    text-align: center;
    line-height: 15px;
    font-size: 15px;
    border-left: 1px solid rgba(103, 65, 55, .6)
}

.player-table .player-row-stats .row:first-child {
    border-left: none
}

.player-table .player-row-stats .row span {
    font-weight: 700;
    font-size: 11px
}

.player-informations {
    text-align: left;
}

.player-card h3,
.player-informations h3 {
    margin: 10px 0 !important;
    font-weight: 700;
    text-align: center;
}


/*! normalize.css v5.0.0 | MIT License | github.com/necolas/normalize.css */

button,
hr,
input {
    overflow: visible
}

audio,
canvas,
progress,
video {
    display: inline-block
}

progress,
sub,
sup {
    vertical-align: baseline
}

[type=checkbox],
[type=radio],
legend {
    box-sizing: border-box;
    padding: 0
}

html {
    font-family: sans-serif;
    line-height: 1.15;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%
}

body {
    margin: 0
}

article,
aside,
details,
figcaption,
figure,
footer,
header,
main,
menu,
nav,
section {
    display: block
}

h1 {
    font-size: 2em;
    margin: .67em 0
}

figure {
    margin: 1em 40px
}

hr {
    box-sizing: content-box;
    height: 0
}

code,
kbd,
pre,
samp {
    font-family: monospace, monospace;
    font-size: 1em
}

a {
    background-color: transparent;
    -webkit-text-decoration-skip: objects
}

a:active,
a:hover {
    outline-width: 0
}

abbr[title] {
    border-bottom: none;
    text-decoration: underline;
    text-decoration: underline dotted
}

b,
strong {
    font-weight: bolder
}

dfn {
    font-style: italic
}

mark {
    background-color: #ff0;
    color: #000
}

small {
    font-size: 80%
}

sub,
sup {
    font-size: 75%;
    line-height: 0;
    position: relative
}

sub {
    bottom: -.25em
}

sup {
    top: -.5em
}

audio:not([controls]) {
    display: none;
    height: 0
}

img {
    border-style: none
}

svg:not(:root) {
    overflow: hidden
}

button,
input,
optgroup,
select,
textarea {
    font-family: sans-serif;
    font-size: 100%;
    line-height: 1.15;
    margin: 0
}

button,
select {
    text-transform: none
}

[type=reset],
[type=submit],
button,
html [type=button] {
    -webkit-appearance: button
}

[type=button]::-moz-focus-inner,
[type=reset]::-moz-focus-inner,
[type=submit]::-moz-focus-inner,
button::-moz-focus-inner {
    border-style: none;
    padding: 0
}

[type=button]:-moz-focusring,
[type=reset]:-moz-focusring,
[type=submit]:-moz-focusring,
button:-moz-focusring {
    outline: ButtonText dotted 1px
}

fieldset {
    border: 1px solid silver;
    margin: 0 2px;
    padding: .35em .625em .75em
}

legend {
    color: inherit;
    display: table;
    max-width: 100%;
    white-space: normal
}

textarea {
    overflow: auto
}

[type=number]::-webkit-inner-spin-button,
[type=number]::-webkit-outer-spin-button {
    height: auto
}

[type=search] {
    -webkit-appearance: textfield;
    outline-offset: -2px
}

[type=search]::-webkit-search-cancel-button,
[type=search]::-webkit-search-decoration {
    -webkit-appearance: none
}

::-webkit-file-upload-button {
    -webkit-appearance: button;
    font: inherit
}

summary {
    display: list-item
}

[hidden],
template {
    display: none
}


/*!
 * animate.css -http://daneden.me/animate
 * Version - 3.5.2
 * Licensed under the MIT license - http://opensource.org/licenses/MIT
 *
 * Copyright (c) 2017 Daniel Eden
 */

.animated {
    animation-duration: 1s;
    animation-fill-mode: both
}

.animated.infinite {
    animation-iteration-count: infinite
}

.animated.hinge {
    animation-duration: 2s
}

.animated.bounceIn,
.animated.bounceOut,
.animated.flipOutX,
.animated.flipOutY {
    animation-duration: .75s
}

@keyframes bounce {
    20%,
    53%,
    80%,
    from,
    to {
        animation-timing-function: cubic-bezier(.215, .61, .355, 1);
        transform: translate3d(0, 0, 0)
    }
    40%,
    43% {
        animation-timing-function: cubic-bezier(.755, .050, .855, .060);
        transform: translate3d(0, -30px, 0)
    }
    70% {
        animation-timing-function: cubic-bezier(.755, .050, .855, .060);
        transform: translate3d(0, -15px, 0)
    }
    90% {
        transform: translate3d(0, -4px, 0)
    }
}

.bounce {
    animation-name: bounce;
    transform-origin: center bottom
}

@keyframes flash {
    50%,
    from,
    to {
        opacity: 1
    }
    25%,
    75% {
        opacity: 0
    }
}

.flash {
    animation-name: flash
}

@keyframes pulse {
    from,
    to {
        transform: scale3d(1, 1, 1)
    }
    50% {
        transform: scale3d(1.05, 1.05, 1.05)
    }
}

.pulse {
    animation-name: pulse
}

@keyframes rubberBand {
    from,
    to {
        transform: scale3d(1, 1, 1)
    }
    30% {
        transform: scale3d(1.25, .75, 1)
    }
    40% {
        transform: scale3d(.75, 1.25, 1)
    }
    50% {
        transform: scale3d(1.15, .85, 1)
    }
    65% {
        transform: scale3d(.95, 1.05, 1)
    }
    75% {
        transform: scale3d(1.05, .95, 1)
    }
}

.rubberBand {
    animation-name: rubberBand
}

@keyframes shake {
    from,
    to {
        transform: translate3d(0, 0, 0)
    }
    10%,
    30%,
    50%,
    70%,
    90% {
        transform: translate3d(-10px, 0, 0)
    }
    20%,
    40%,
    60%,
    80% {
        transform: translate3d(10px, 0, 0)
    }
}

.shake {
    animation-name: shake
}

@keyframes headShake {
    0% {
        transform: translateX(0)
    }
    6.5% {
        transform: translateX(-6px) rotateY(-9deg)
    }
    18.5% {
        transform: translateX(5px) rotateY(7deg)
    }
    31.5% {
        transform: translateX(-3px) rotateY(-5deg)
    }
    43.5% {
        transform: translateX(2px) rotateY(3deg)
    }
    50% {
        transform: translateX(0)
    }
}

.headShake {
    animation-timing-function: ease-in-out;
    animation-name: headShake
}

@keyframes swing {
    20% {
        transform: rotate3d(0, 0, 1, 15deg)
    }
    40% {
        transform: rotate3d(0, 0, 1, -10deg)
    }
    60% {
        transform: rotate3d(0, 0, 1, 5deg)
    }
    80% {
        transform: rotate3d(0, 0, 1, -5deg)
    }
    to {
        transform: rotate3d(0, 0, 1, 0deg)
    }
}

.swing {
    transform-origin: top center;
    animation-name: swing
}

@keyframes tada {
    from,
    to {
        transform: scale3d(1, 1, 1)
    }
    10%,
    20% {
        transform: scale3d(.9, .9, .9) rotate3d(0, 0, 1, -3deg)
    }
    30%,
    50%,
    70%,
    90% {
        transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)
    }
    40%,
    60%,
    80% {
        transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)
    }
}

.tada {
    animation-name: tada
}

@keyframes wobble {
    from,
    to {
        transform: none
    }
    15% {
        transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg)
    }
    30% {
        transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg)
    }
    45% {
        transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg)
    }
    60% {
        transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg)
    }
    75% {
        transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg)
    }
}

.wobble {
    animation-name: wobble
}

@keyframes jello {
    11.1%,
    from,
    to {
        transform: none
    }
    22.2% {
        transform: skewX(-12.5deg) skewY(-12.5deg)
    }
    33.3% {
        transform: skewX(6.25deg) skewY(6.25deg)
    }
    44.4% {
        transform: skewX(-3.125deg) skewY(-3.125deg)
    }
    55.5% {
        transform: skewX(1.5625deg) skewY(1.5625deg)
    }
    66.6% {
        transform: skewX(-.78125deg) skewY(-.78125deg)
    }
    77.7% {
        transform: skewX(.390625deg) skewY(.390625deg)
    }
    88.8% {
        transform: skewX(-.1953125deg) skewY(-.1953125deg)
    }
}

.jello {
    animation-name: jello;
    transform-origin: center
}

@keyframes bounceIn {
    20%,
    40%,
    60%,
    80%,
    from,
    to {
        animation-timing-function: cubic-bezier(.215, .61, .355, 1)
    }
    0% {
        opacity: 0;
        transform: scale3d(.3, .3, .3)
    }
    20% {
        transform: scale3d(1.1, 1.1, 1.1)
    }
    40% {
        transform: scale3d(.9, .9, .9)
    }
    60% {
        opacity: 1;
        transform: scale3d(1.03, 1.03, 1.03)
    }
    80% {
        transform: scale3d(.97, .97, .97)
    }
    to {
        opacity: 1;
        transform: scale3d(1, 1, 1)
    }
}

.bounceIn {
    animation-name: bounceIn
}

@keyframes bounceInDown {
    60%,
    75%,
    90%,
    from,
    to {
        animation-timing-function: cubic-bezier(.215, .61, .355, 1)
    }
    0% {
        opacity: 0;
        transform: translate3d(0, -3000px, 0)
    }
    60% {
        opacity: 1;
        transform: translate3d(0, 25px, 0)
    }
    75% {
        transform: translate3d(0, -10px, 0)
    }
    90% {
        transform: translate3d(0, 5px, 0)
    }
    to {
        transform: none
    }
}

.bounceInDown {
    animation-name: bounceInDown
}

@keyframes bounceInLeft {
    60%,
    75%,
    90%,
    from,
    to {
        animation-timing-function: cubic-bezier(.215, .61, .355, 1)
    }
    0% {
        opacity: 0;
        transform: translate3d(-3000px, 0, 0)
    }
    60% {
        opacity: 1;
        transform: translate3d(25px, 0, 0)
    }
    75% {
        transform: translate3d(-10px, 0, 0)
    }
    90% {
        transform: translate3d(5px, 0, 0)
    }
    to {
        transform: none
    }
}

.bounceInLeft {
    animation-name: bounceInLeft
}

@keyframes bounceInRight {
    60%,
    75%,
    90%,
    from,
    to {
        animation-timing-function: cubic-bezier(.215, .61, .355, 1)
    }
    from {
        opacity: 0;
        transform: translate3d(3000px, 0, 0)
    }
    60% {
        opacity: 1;
        transform: translate3d(-25px, 0, 0)
    }
    75% {
        transform: translate3d(10px, 0, 0)
    }
    90% {
        transform: translate3d(-5px, 0, 0)
    }
    to {
        transform: none
    }
}

.bounceInRight {
    animation-name: bounceInRight
}

@keyframes bounceInUp {
    60%,
    75%,
    90%,
    from,
    to {
        animation-timing-function: cubic-bezier(.215, .61, .355, 1)
    }
    from {
        opacity: 0;
        transform: translate3d(0, 3000px, 0)
    }
    60% {
        opacity: 1;
        transform: translate3d(0, -20px, 0)
    }
    75% {
        transform: translate3d(0, 10px, 0)
    }
    90% {
        transform: translate3d(0, -5px, 0)
    }
    to {
        transform: translate3d(0, 0, 0)
    }
}

.bounceInUp {
    animation-name: bounceInUp
}

@keyframes bounceOut {
    20% {
        transform: scale3d(.9, .9, .9)
    }
    50%,
    55% {
        opacity: 1;
        transform: scale3d(1.1, 1.1, 1.1)
    }
    to {
        opacity: 0;
        transform: scale3d(.3, .3, .3)
    }
}

.bounceOut {
    animation-name: bounceOut
}

@keyframes bounceOutDown {
    20% {
        transform: translate3d(0, 10px, 0)
    }
    40%,
    45% {
        opacity: 1;
        transform: translate3d(0, -20px, 0)
    }
    to {
        opacity: 0;
        transform: translate3d(0, 2000px, 0)
    }
}

.bounceOutDown {
    animation-name: bounceOutDown
}

@keyframes bounceOutLeft {
    20% {
        opacity: 1;
        transform: translate3d(20px, 0, 0)
    }
    to {
        opacity: 0;
        transform: translate3d(-2000px, 0, 0)
    }
}

.bounceOutLeft {
    animation-name: bounceOutLeft
}

@keyframes bounceOutRight {
    20% {
        opacity: 1;
        transform: translate3d(-20px, 0, 0)
    }
    to {
        opacity: 0;
        transform: translate3d(2000px, 0, 0)
    }
}

.bounceOutRight {
    animation-name: bounceOutRight
}

@keyframes bounceOutUp {
    20% {
        transform: translate3d(0, -10px, 0)
    }
    40%,
    45% {
        opacity: 1;
        transform: translate3d(0, 20px, 0)
    }
    to {
        opacity: 0;
        transform: translate3d(0, -2000px, 0)
    }
}

.bounceOutUp {
    animation-name: bounceOutUp
}

@keyframes fadeIn {
    from {
        opacity: 0
    }
    to {
        opacity: 1
    }
}

.fadeIn {
    animation-name: fadeIn
}

@keyframes fadeInDown {
    from {
        opacity: 0;
        transform: translate3d(0, -100%, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInDown {
    animation-name: fadeInDown
}

@keyframes fadeInDownBig {
    from {
        opacity: 0;
        transform: translate3d(0, -2000px, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInDownBig {
    animation-name: fadeInDownBig
}

@keyframes fadeInLeft {
    from {
        opacity: 0;
        transform: translate3d(-100%, 0, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInLeft {
    animation-name: fadeInLeft
}

@keyframes fadeInLeftBig {
    from {
        opacity: 0;
        transform: translate3d(-2000px, 0, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInLeftBig {
    animation-name: fadeInLeftBig
}

@keyframes fadeInRight {
    from {
        opacity: 0;
        transform: translate3d(100%, 0, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInRight {
    animation-name: fadeInRight
}

@keyframes fadeInRightBig {
    from {
        opacity: 0;
        transform: translate3d(2000px, 0, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInRightBig {
    animation-name: fadeInRightBig
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translate3d(0, 100%, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInUp {
    animation-name: fadeInUp
}

@keyframes fadeInUpBig {
    from {
        opacity: 0;
        transform: translate3d(0, 2000px, 0)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.fadeInUpBig {
    animation-name: fadeInUpBig
}

@keyframes fadeOut {
    from {
        opacity: 1
    }
    to {
        opacity: 0
    }
}

.fadeOut {
    animation-name: fadeOut
}

@keyframes fadeOutDown {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(0, 100%, 0)
    }
}

.fadeOutDown {
    animation-name: fadeOutDown
}

@keyframes fadeOutDownBig {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(0, 2000px, 0)
    }
}

.fadeOutDownBig {
    animation-name: fadeOutDownBig
}

@keyframes fadeOutLeft {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(-100%, 0, 0)
    }
}

.fadeOutLeft {
    animation-name: fadeOutLeft
}

@keyframes fadeOutLeftBig {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(-2000px, 0, 0)
    }
}

.fadeOutLeftBig {
    animation-name: fadeOutLeftBig
}

@keyframes fadeOutRight {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(100%, 0, 0)
    }
}

.fadeOutRight {
    animation-name: fadeOutRight
}

@keyframes fadeOutRightBig {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(2000px, 0, 0)
    }
}

.fadeOutRightBig {
    animation-name: fadeOutRightBig
}

@keyframes fadeOutUp {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(0, -100%, 0)
    }
}

.fadeOutUp {
    animation-name: fadeOutUp
}

@keyframes fadeOutUpBig {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(0, -2000px, 0)
    }
}

.fadeOutUpBig {
    animation-name: fadeOutUpBig
}

@keyframes flip {
    from {
        transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
        animation-timing-function: ease-out
    }
    40% {
        transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
        animation-timing-function: ease-out
    }
    50% {
        transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
        animation-timing-function: ease-in
    }
    80% {
        transform: perspective(400px) scale3d(.95, .95, .95);
        animation-timing-function: ease-in
    }
    to {
        transform: perspective(400px);
        animation-timing-function: ease-in
    }
}

.animated.flip {
    -webkit-backface-visibility: visible;
    backface-visibility: visible;
    animation-name: flip
}

@keyframes flipInX {
    from {
        transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
        animation-timing-function: ease-in;
        opacity: 0
    }
    40% {
        transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
        animation-timing-function: ease-in
    }
    60% {
        transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
        opacity: 1
    }
    80% {
        transform: perspective(400px) rotate3d(1, 0, 0, -5deg)
    }
    to {
        transform: perspective(400px)
    }
}

.flipInX {
    -webkit-backface-visibility: visible!important;
    backface-visibility: visible!important;
    animation-name: flipInX
}

.flipInY,
.flipOutX {
    -webkit-backface-visibility: visible!important
}

@keyframes flipInY {
    from {
        transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
        animation-timing-function: ease-in;
        opacity: 0
    }
    40% {
        transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
        animation-timing-function: ease-in
    }
    60% {
        transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
        opacity: 1
    }
    80% {
        transform: perspective(400px) rotate3d(0, 1, 0, -5deg)
    }
    to {
        transform: perspective(400px)
    }
}

.flipInY {
    backface-visibility: visible!important;
    animation-name: flipInY
}

@keyframes flipOutX {
    from {
        transform: perspective(400px)
    }
    30% {
        transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
        opacity: 1
    }
    to {
        transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
        opacity: 0
    }
}

.flipOutX {
    animation-name: flipOutX;
    backface-visibility: visible!important
}

@keyframes flipOutY {
    from {
        transform: perspective(400px)
    }
    30% {
        transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
        opacity: 1
    }
    to {
        transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
        opacity: 0
    }
}

.flipOutY {
    -webkit-backface-visibility: visible!important;
    backface-visibility: visible!important;
    animation-name: flipOutY
}

@keyframes lightSpeedIn {
    from {
        transform: translate3d(100%, 0, 0) skewX(-30deg);
        opacity: 0
    }
    60% {
        transform: skewX(20deg);
        opacity: 1
    }
    80% {
        transform: skewX(-5deg);
        opacity: 1
    }
    to {
        transform: none;
        opacity: 1
    }
}

.lightSpeedIn {
    animation-name: lightSpeedIn;
    animation-timing-function: ease-out
}

@keyframes lightSpeedOut {
    from {
        opacity: 1
    }
    to {
        transform: translate3d(100%, 0, 0) skewX(30deg);
        opacity: 0
    }
}

.lightSpeedOut {
    animation-name: lightSpeedOut;
    animation-timing-function: ease-in
}

@keyframes rotateIn {
    from {
        transform-origin: center;
        transform: rotate3d(0, 0, 1, -200deg);
        opacity: 0
    }
    to {
        transform-origin: center;
        transform: none;
        opacity: 1
    }
}

.rotateIn {
    animation-name: rotateIn
}

@keyframes rotateInDownLeft {
    from {
        transform-origin: left bottom;
        transform: rotate3d(0, 0, 1, -45deg);
        opacity: 0
    }
    to {
        transform-origin: left bottom;
        transform: none;
        opacity: 1
    }
}

.rotateInDownLeft {
    animation-name: rotateInDownLeft
}

@keyframes rotateInDownRight {
    from {
        transform-origin: right bottom;
        transform: rotate3d(0, 0, 1, 45deg);
        opacity: 0
    }
    to {
        transform-origin: right bottom;
        transform: none;
        opacity: 1
    }
}

.rotateInDownRight {
    animation-name: rotateInDownRight
}

@keyframes rotateInUpLeft {
    from {
        transform-origin: left bottom;
        transform: rotate3d(0, 0, 1, 45deg);
        opacity: 0
    }
    to {
        transform-origin: left bottom;
        transform: none;
        opacity: 1
    }
}

.rotateInUpLeft {
    animation-name: rotateInUpLeft
}

@keyframes rotateInUpRight {
    from {
        transform-origin: right bottom;
        transform: rotate3d(0, 0, 1, -90deg);
        opacity: 0
    }
    to {
        transform-origin: right bottom;
        transform: none;
        opacity: 1
    }
}

.rotateInUpRight {
    animation-name: rotateInUpRight
}

@keyframes rotateOut {
    from {
        transform-origin: center;
        opacity: 1
    }
    to {
        transform-origin: center;
        transform: rotate3d(0, 0, 1, 200deg);
        opacity: 0
    }
}

.rotateOut {
    animation-name: rotateOut
}

@keyframes rotateOutDownLeft {
    from {
        transform-origin: left bottom;
        opacity: 1
    }
    to {
        transform-origin: left bottom;
        transform: rotate3d(0, 0, 1, 45deg);
        opacity: 0
    }
}

.rotateOutDownLeft {
    animation-name: rotateOutDownLeft
}

@keyframes rotateOutDownRight {
    from {
        transform-origin: right bottom;
        opacity: 1
    }
    to {
        transform-origin: right bottom;
        transform: rotate3d(0, 0, 1, -45deg);
        opacity: 0
    }
}

.rotateOutDownRight {
    animation-name: rotateOutDownRight
}

@keyframes rotateOutUpLeft {
    from {
        transform-origin: left bottom;
        opacity: 1
    }
    to {
        transform-origin: left bottom;
        transform: rotate3d(0, 0, 1, -45deg);
        opacity: 0
    }
}

.rotateOutUpLeft {
    animation-name: rotateOutUpLeft
}

@keyframes rotateOutUpRight {
    from {
        transform-origin: right bottom;
        opacity: 1
    }
    to {
        transform-origin: right bottom;
        transform: rotate3d(0, 0, 1, 90deg);
        opacity: 0
    }
}

.rotateOutUpRight {
    animation-name: rotateOutUpRight
}

@keyframes hinge {
    0% {
        transform-origin: top left;
        animation-timing-function: ease-in-out
    }
    20%,
    60% {
        transform: rotate3d(0, 0, 1, 80deg);
        transform-origin: top left;
        animation-timing-function: ease-in-out
    }
    40%,
    80% {
        transform: rotate3d(0, 0, 1, 60deg);
        transform-origin: top left;
        animation-timing-function: ease-in-out;
        opacity: 1
    }
    to {
        transform: translate3d(0, 700px, 0);
        opacity: 0
    }
}

.hinge {
    animation-name: hinge
}

@keyframes jackInTheBox {
    from {
        opacity: 0;
        transform: scale(.1) rotate(30deg);
        transform-origin: center bottom
    }
    50% {
        transform: rotate(-10deg)
    }
    70% {
        transform: rotate(3deg)
    }
    to {
        opacity: 1;
        transform: scale(1)
    }
}

.jackInTheBox {
    animation-name: jackInTheBox
}

@keyframes rollIn {
    from {
        opacity: 0;
        transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg)
    }
    to {
        opacity: 1;
        transform: none
    }
}

.rollIn {
    animation-name: rollIn
}

@keyframes rollOut {
    from {
        opacity: 1
    }
    to {
        opacity: 0;
        transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg)
    }
}

.rollOut {
    animation-name: rollOut
}

@keyframes zoomIn {
    from {
        opacity: 0;
        transform: scale3d(.3, .3, .3)
    }
    50% {
        opacity: 1
    }
}

.zoomIn {
    animation-name: zoomIn
}

@keyframes zoomInDown {
    from {
        opacity: 0;
        transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);
        animation-timing-function: cubic-bezier(.55, .055, .675, .19)
    }
    60% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);
        animation-timing-function: cubic-bezier(.175, .885, .32, 1)
    }
}

.zoomInDown {
    animation-name: zoomInDown
}

@keyframes zoomInLeft {
    from {
        opacity: 0;
        transform: scale3d(.1, .1, .1) translate3d(-1000px, 0, 0);
        animation-timing-function: cubic-bezier(.55, .055, .675, .19)
    }
    60% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(10px, 0, 0);
        animation-timing-function: cubic-bezier(.175, .885, .32, 1)
    }
}

.zoomInLeft {
    animation-name: zoomInLeft
}

@keyframes zoomInRight {
    from {
        opacity: 0;
        transform: scale3d(.1, .1, .1) translate3d(1000px, 0, 0);
        animation-timing-function: cubic-bezier(.55, .055, .675, .19)
    }
    60% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(-10px, 0, 0);
        animation-timing-function: cubic-bezier(.175, .885, .32, 1)
    }
}

.zoomInRight {
    animation-name: zoomInRight
}

@keyframes zoomInUp {
    from {
        opacity: 0;
        transform: scale3d(.1, .1, .1) translate3d(0, 1000px, 0);
        animation-timing-function: cubic-bezier(.55, .055, .675, .19)
    }
    60% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);
        animation-timing-function: cubic-bezier(.175, .885, .32, 1)
    }
}

.zoomInUp {
    animation-name: zoomInUp
}

@keyframes zoomOut {
    from {
        opacity: 1
    }
    50% {
        opacity: 0;
        transform: scale3d(.3, .3, .3)
    }
    to {
        opacity: 0
    }
}

.zoomOut {
    animation-name: zoomOut
}

@keyframes zoomOutDown {
    40% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);
        animation-timing-function: cubic-bezier(.55, .055, .675, .19)
    }
    to {
        opacity: 0;
        transform: scale3d(.1, .1, .1) translate3d(0, 2000px, 0);
        transform-origin: center bottom;
        animation-timing-function: cubic-bezier(.175, .885, .32, 1)
    }
}

.zoomOutDown {
    animation-name: zoomOutDown
}

@keyframes zoomOutLeft {
    40% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(42px, 0, 0)
    }
    to {
        opacity: 0;
        transform: scale(.1) translate3d(-2000px, 0, 0);
        transform-origin: left center
    }
}

.zoomOutLeft {
    animation-name: zoomOutLeft
}

@keyframes zoomOutRight {
    40% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(-42px, 0, 0)
    }
    to {
        opacity: 0;
        transform: scale(.1) translate3d(2000px, 0, 0);
        transform-origin: right center
    }
}

.zoomOutRight {
    animation-name: zoomOutRight
}

@keyframes zoomOutUp {
    40% {
        opacity: 1;
        transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);
        animation-timing-function: cubic-bezier(.55, .055, .675, .19)
    }
    to {
        opacity: 0;
        transform: scale3d(.1, .1, .1) translate3d(0, -2000px, 0);
        transform-origin: center bottom;
        animation-timing-function: cubic-bezier(.175, .885, .32, 1)
    }
}

.zoomOutUp {
    animation-name: zoomOutUp
}

@keyframes slideInDown {
    from {
        transform: translate3d(0, -100%, 0);
        visibility: visible
    }
    to {
        transform: translate3d(0, 0, 0)
    }
}

.slideInDown {
    animation-name: slideInDown
}

@keyframes slideInLeft {
    from {
        transform: translate3d(-100%, 0, 0);
        visibility: visible
    }
    to {
        transform: translate3d(0, 0, 0)
    }
}

.slideInLeft {
    animation-name: slideInLeft
}

@keyframes slideInRight {
    from {
        transform: translate3d(100%, 0, 0);
        visibility: visible
    }
    to {
        transform: translate3d(0, 0, 0)
    }
}

.slideInRight {
    animation-name: slideInRight
}

@keyframes slideInUp {
    from {
        transform: translate3d(0, 100%, 0);
        visibility: visible
    }
    to {
        transform: translate3d(0, 0, 0)
    }
}

.slideInUp {
    animation-name: slideInUp
}

@keyframes slideOutDown {
    from {
        transform: translate3d(0, 0, 0)
    }
    to {
        visibility: hidden;
        transform: translate3d(0, 100%, 0)
    }
}

.slideOutDown {
    animation-name: slideOutDown
}

@keyframes slideOutLeft {
    from {
        transform: translate3d(0, 0, 0)
    }
    to {
        visibility: hidden;
        transform: translate3d(-100%, 0, 0)
    }
}

.slideOutLeft {
    animation-name: slideOutLeft
}

@keyframes slideOutRight {
    from {
        transform: translate3d(0, 0, 0)
    }
    to {
        visibility: hidden;
        transform: translate3d(100%, 0, 0)
    }
}

.slideOutRight {
    animation-name: slideOutRight
}

@keyframes slideOutUp {
    from {
        transform: translate3d(0, 0, 0)
    }
    to {
        visibility: hidden;
        transform: translate3d(0, -100%, 0)
    }
}

.slideOutUp {
    animation-name: slideOutUp
}

@font-face {
    font-family: icomoon;
    src: url(/fonts/icomoon.eot?3p0rtw);
    src: url(/fonts/icomoon.eot?#iefix3p0rtw) format('embedded-opentype'), url(/fonts/icomoon.woff?3p0rtw) format('woff'), url(/fonts/icomoon.ttf?3p0rtw) format('truetype');
    font-weight: 400;
    font-style: normal
}

[class*=" icon-"],
[class^=icon-] {
    font-family: icomoon;
    speak: none;
    font-style: normal;
    font-weight: 400;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    min-width: 1em;
    display: inline-block;
    text-align: center;
    font-size: 16px;
    vertical-align: middle;
    position: relative;
    top: -1px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale
}

.icon-2x {
    font-size: 32px
}

.icon-3x {
    font-size: 48px
}

.icon-bordered {
    padding: 5px;
    border: 2px solid;
    border-radius: 50%
}

.icon-home:before {
    content: "\e900"
}

.icon-home2:before {
    content: "\e901"
}

.icon-home5:before {
    content: "\e904"
}

.icon-home7:before {
    content: "\e906"
}

.icon-home8:before {
    content: "\e907"
}

.icon-home9:before {
    content: "\e908"
}

.icon-office:before {
    content: "\e909"
}

.icon-city:before {
    content: "\e90a"
}

.icon-newspaper:before {
    content: "\e90b"
}

.icon-magazine:before {
    content: "\e90c"
}

.icon-design:before {
    content: "\e90d"
}

.icon-pencil:before {
    content: "\e90e"
}

.icon-pencil3:before {
    content: "\e910"
}

.icon-pencil4:before {
    content: "\e911"
}

.icon-pencil5:before {
    content: "\e912"
}

.icon-pencil6:before {
    content: "\e913"
}

.icon-pencil7:before {
    content: "\e914"
}

.icon-eraser:before {
    content: "\e915"
}

.icon-eraser2:before {
    content: "\e916"
}

.icon-eraser3:before {
    content: "\e917"
}

.icon-quill2:before {
    content: "\e919"
}

.icon-quill4:before {
    content: "\e91b"
}

.icon-pen:before {
    content: "\e91c"
}

.icon-pen-plus:before {
    content: "\e91d"
}

.icon-pen-minus:before {
    content: "\e91e"
}

.icon-pen2:before {
    content: "\e91f"
}

.icon-blog:before {
    content: "\e925"
}

.icon-pen6:before {
    content: "\e927"
}

.icon-brush:before {
    content: "\e928"
}

.icon-spray:before {
    content: "\e929"
}

.icon-color-sampler:before {
    content: "\e92c"
}

.icon-toggle:before {
    content: "\e92d"
}

.icon-bucket:before {
    content: "\e92e"
}

.icon-gradient:before {
    content: "\e930"
}

.icon-eyedropper:before {
    content: "\e931"
}

.icon-eyedropper2:before {
    content: "\e932"
}

.icon-eyedropper3:before {
    content: "\e933"
}

.icon-droplet:before {
    content: "\e934"
}

.icon-droplet2:before {
    content: "\e935"
}

.icon-color-clear:before {
    content: "\e937"
}

.icon-paint-format:before {
    content: "\e938"
}

.icon-stamp:before {
    content: "\e939"
}

.icon-image2:before {
    content: "\e93c"
}

.icon-image-compare:before {
    content: "\e93d"
}

.icon-images2:before {
    content: "\e93e"
}

.icon-image3:before {
    content: "\e93f"
}

.icon-images3:before {
    content: "\e940"
}

.icon-image4:before {
    content: "\e941"
}

.icon-image5:before {
    content: "\e942"
}

.icon-camera:before {
    content: "\e944"
}

.icon-shutter:before {
    content: "\e947"
}

.icon-headphones:before {
    content: "\e948"
}

.icon-headset:before {
    content: "\e949"
}

.icon-music:before {
    content: "\e94a"
}

.icon-album:before {
    content: "\e950"
}

.icon-tape:before {
    content: "\e952"
}

.icon-piano:before {
    content: "\e953"
}

.icon-speakers:before {
    content: "\e956"
}

.icon-play:before {
    content: "\e957"
}

.icon-clapboard-play:before {
    content: "\e959"
}

.icon-clapboard:before {
    content: "\e95a"
}

.icon-media:before {
    content: "\e95b"
}

.icon-presentation:before {
    content: "\e95c"
}

.icon-movie:before {
    content: "\e95d"
}

.icon-film:before {
    content: "\e95e"
}

.icon-film2:before {
    content: "\e95f"
}

.icon-film3:before {
    content: "\e960"
}

.icon-film4:before {
    content: "\e961"
}

.icon-video-camera:before {
    content: "\e962"
}

.icon-video-camera2:before {
    content: "\e963"
}

.icon-video-camera-slash:before {
    content: "\e964"
}

.icon-video-camera3:before {
    content: "\e965"
}

.icon-dice:before {
    content: "\e96a"
}

.icon-chess-king:before {
    content: "\e972"
}

.icon-chess-queen:before {
    content: "\e973"
}

.icon-chess:before {
    content: "\e978"
}

.icon-megaphone:before {
    content: "\e97a"
}

.icon-new:before {
    content: "\e97b"
}

.icon-connection:before {
    content: "\e97c"
}

.icon-station:before {
    content: "\e981"
}

.icon-satellite-dish2:before {
    content: "\e98a"
}

.icon-feed:before {
    content: "\e9b3"
}

.icon-mic2:before {
    content: "\e9ce"
}

.icon-mic-off2:before {
    content: "\e9e0"
}

.icon-book:before {
    content: "\e9e1"
}

.icon-book2:before {
    content: "\e9e9"
}

.icon-book-play:before {
    content: "\e9fd"
}

.icon-book3:before {
    content: "\ea01"
}

.icon-bookmark:before {
    content: "\ea02"
}

.icon-books:before {
    content: "\ea03"
}

.icon-archive:before {
    content: "\ea04"
}

.icon-reading:before {
    content: "\ea05"
}

.icon-library2:before {
    content: "\ea06"
}

.icon-graduation2:before {
    content: "\ea07"
}

.icon-file-text:before {
    content: "\ea08"
}

.icon-profile:before {
    content: "\ea09"
}

.icon-file-empty:before {
    content: "\ea0a"
}

.icon-file-empty2:before {
    content: "\ea0b"
}

.icon-files-empty:before {
    content: "\ea0c"
}

.icon-files-empty2:before {
    content: "\ea0d"
}

.icon-file-plus:before {
    content: "\ea0e"
}

.icon-file-plus2:before {
    content: "\ea0f"
}

.icon-file-minus:before {
    content: "\ea10"
}

.icon-file-minus2:before {
    content: "\ea11"
}

.icon-file-download:before {
    content: "\ea12"
}

.icon-file-download2:before {
    content: "\ea13"
}

.icon-file-upload:before {
    content: "\ea14"
}

.icon-file-upload2:before {
    content: "\ea15"
}

.icon-file-check:before {
    content: "\ea16"
}

.icon-file-check2:before {
    content: "\ea17"
}

.icon-file-eye:before {
    content: "\ea18"
}

.icon-file-eye2:before {
    content: "\ea19"
}

.icon-file-text2:before {
    content: "\ea1a"
}

.icon-file-text3:before {
    content: "\ea1b"
}

.icon-file-picture:before {
    content: "\ea1c"
}

.icon-file-picture2:before {
    content: "\ea1d"
}

.icon-file-music:before {
    content: "\ea1e"
}

.icon-file-music2:before {
    content: "\ea1f"
}

.icon-file-play:before {
    content: "\ea20"
}

.icon-file-play2:before {
    content: "\ea21"
}

.icon-file-video:before {
    content: "\ea22"
}

.icon-file-video2:before {
    content: "\ea23"
}

.icon-copy:before {
    content: "\ea24"
}

.icon-copy2:before {
    content: "\ea25"
}

.icon-file-zip:before {
    content: "\ea26"
}

.icon-file-zip2:before {
    content: "\ea27"
}

.icon-file-xml:before {
    content: "\ea28"
}

.icon-file-xml2:before {
    content: "\ea29"
}

.icon-file-css:before {
    content: "\ea2a"
}

.icon-file-css2:before {
    content: "\ea2b"
}

.icon-file-presentation:before {
    content: "\ea2c"
}

.icon-file-presentation2:before {
    content: "\ea2d"
}

.icon-file-stats:before {
    content: "\ea2e"
}

.icon-file-stats2:before {
    content: "\ea2f"
}

.icon-file-locked:before {
    content: "\ea30"
}

.icon-file-locked2:before {
    content: "\ea31"
}

.icon-file-spreadsheet:before {
    content: "\ea32"
}

.icon-file-spreadsheet2:before {
    content: "\ea33"
}

.icon-copy3:before {
    content: "\ea34"
}

.icon-copy4:before {
    content: "\ea35"
}

.icon-paste:before {
    content: "\ea36"
}

.icon-paste2:before {
    content: "\ea37"
}

.icon-paste3:before {
    content: "\ea38"
}

.icon-paste4:before {
    content: "\ea39"
}

.icon-stack:before {
    content: "\ea3a"
}

.icon-stack2:before {
    content: "\ea3b"
}

.icon-stack3:before {
    content: "\ea3c"
}

.icon-folder:before {
    content: "\ea3d"
}

.icon-folder-search:before {
    content: "\ea3e"
}

.icon-folder-download:before {
    content: "\ea3f"
}

.icon-folder-upload:before {
    content: "\ea40"
}

.icon-folder-plus:before {
    content: "\ea41"
}

.icon-folder-plus2:before {
    content: "\ea42"
}

.icon-folder-minus:before {
    content: "\ea43"
}

.icon-folder-minus2:before {
    content: "\ea44"
}

.icon-folder-check:before {
    content: "\ea45"
}

.icon-folder-heart:before {
    content: "\ea46"
}

.icon-folder-remove:before {
    content: "\ea47"
}

.icon-folder2:before {
    content: "\ea48"
}

.icon-folder-open:before {
    content: "\ea49"
}

.icon-folder3:before {
    content: "\ea4a"
}

.icon-folder4:before {
    content: "\ea4b"
}

.icon-folder-plus3:before {
    content: "\ea4c"
}

.icon-folder-minus3:before {
    content: "\ea4d"
}

.icon-folder-plus4:before {
    content: "\ea4e"
}

.icon-folder-minus4:before {
    content: "\ea4f"
}

.icon-folder-download2:before {
    content: "\ea50"
}

.icon-folder-upload2:before {
    content: "\ea51"
}

.icon-folder-download3:before {
    content: "\ea52"
}

.icon-folder-upload3:before {
    content: "\ea53"
}

.icon-folder5:before {
    content: "\ea54"
}

.icon-folder-open2:before {
    content: "\ea55"
}

.icon-folder6:before {
    content: "\ea56"
}

.icon-folder-open3:before {
    content: "\ea57"
}

.icon-certificate:before {
    content: "\ea58"
}

.icon-cc:before {
    content: "\ea59"
}

.icon-price-tag:before {
    content: "\ea5a"
}

.icon-price-tag2:before {
    content: "\ea5b"
}

.icon-price-tags:before {
    content: "\ea5c"
}

.icon-price-tag3:before {
    content: "\ea5d"
}

.icon-price-tags2:before {
    content: "\ea5e"
}

.icon-barcode2:before {
    content: "\ea5f"
}

.icon-qrcode:before {
    content: "\ea60"
}

.icon-ticket:before {
    content: "\ea61"
}

.icon-theater:before {
    content: "\ea62"
}

.icon-store:before {
    content: "\ea63"
}

.icon-store2:before {
    content: "\ea64"
}

.icon-cart:before {
    content: "\ea65"
}

.icon-cart2:before {
    content: "\ea66"
}

.icon-cart4:before {
    content: "\ea67"
}

.icon-cart5:before {
    content: "\ea68"
}

.icon-cart-add:before {
    content: "\ea69"
}

.icon-cart-add2:before {
    content: "\ea6a"
}

.icon-cart-remove:before {
    content: "\ea6b"
}

.icon-basket:before {
    content: "\ea6c"
}

.icon-bag:before {
    content: "\ea6d"
}

.icon-percent:before {
    content: "\ea6f"
}

.icon-coins:before {
    content: "\ea70"
}

.icon-coin-dollar:before {
    content: "\ea71"
}

.icon-coin-euro:before {
    content: "\ea72"
}

.icon-coin-pound:before {
    content: "\ea73"
}

.icon-coin-yen:before {
    content: "\ea74"
}

.icon-piggy-bank:before {
    content: "\ea75"
}

.icon-wallet:before {
    content: "\ea76"
}

.icon-cash:before {
    content: "\ea77"
}

.icon-cash2:before {
    content: "\ea78"
}

.icon-cash3:before {
    content: "\ea79"
}

.icon-cash4:before {
    content: "\ea7a"
}

.icon-credit-card:before {
    content: "\ea6e"
}

.icon-credit-card2:before {
    content: "\ea7b"
}

.icon-calculator4:before {
    content: "\ea7c"
}

.icon-calculator2:before {
    content: "\ea7d"
}

.icon-calculator3:before {
    content: "\ea7e"
}

.icon-chip:before {
    content: "\ea7f"
}

.icon-lifebuoy:before {
    content: "\ea80"
}

.icon-phone:before {
    content: "\ea81"
}

.icon-phone2:before {
    content: "\ea82"
}

.icon-phone-slash:before {
    content: "\ea83"
}

.icon-phone-wave:before {
    content: "\ea84"
}

.icon-phone-plus:before {
    content: "\ea85"
}

.icon-phone-minus:before {
    content: "\ea86"
}

.icon-phone-plus2:before {
    content: "\ea87"
}

.icon-phone-minus2:before {
    content: "\ea88"
}

.icon-phone-incoming:before {
    content: "\ea89"
}

.icon-phone-outgoing:before {
    content: "\ea8a"
}

.icon-phone-hang-up:before {
    content: "\ea8e"
}

.icon-address-book:before {
    content: "\ea90"
}

.icon-address-book2:before {
    content: "\ea91"
}

.icon-address-book3:before {
    content: "\ea92"
}

.icon-notebook:before {
    content: "\ea93"
}

.icon-envelop:before {
    content: "\ea94"
}

.icon-envelop2:before {
    content: "\ea95"
}

.icon-envelop3:before {
    content: "\ea96"
}

.icon-envelop4:before {
    content: "\ea97"
}

.icon-envelop5:before {
    content: "\ea98"
}

.icon-mailbox:before {
    content: "\ea99"
}

.icon-pushpin:before {
    content: "\ea9a"
}

.icon-location3:before {
    content: "\ea9d"
}

.icon-location4:before {
    content: "\ea9e"
}

.icon-compass4:before {
    content: "\ea9f"
}

.icon-map:before {
    content: "\eaa0"
}

.icon-map4:before {
    content: "\eaa1"
}

.icon-map5:before {
    content: "\eaa2"
}

.icon-direction:before {
    content: "\eaa3"
}

.icon-reset:before {
    content: "\eaa4"
}

.icon-history:before {
    content: "\eaa5"
}

.icon-watch:before {
    content: "\eaa6"
}

.icon-watch2:before {
    content: "\eaa7"
}

.icon-alarm:before {
    content: "\eaa8"
}

.icon-alarm-add:before {
    content: "\eaa9"
}

.icon-alarm-check:before {
    content: "\eaaa"
}

.icon-alarm-cancel:before {
    content: "\eaab"
}

.icon-bell2:before {
    content: "\eaac"
}

.icon-bell3:before {
    content: "\eaad"
}

.icon-bell-plus:before {
    content: "\eaae"
}

.icon-bell-minus:before {
    content: "\eaaf"
}

.icon-bell-check:before {
    content: "\eab0"
}

.icon-bell-cross:before {
    content: "\eab1"
}

.icon-calendar:before {
    content: "\eab2"
}

.icon-calendar2:before {
    content: "\eab3"
}

.icon-calendar3:before {
    content: "\eab4"
}

.icon-calendar52:before {
    content: "\eab6"
}

.icon-printer:before {
    content: "\eab7"
}

.icon-printer2:before {
    content: "\eab8"
}

.icon-printer4:before {
    content: "\eab9"
}

.icon-shredder:before {
    content: "\eaba"
}

.icon-mouse:before {
    content: "\eabb"
}

.icon-mouse-left:before {
    content: "\eabc"
}

.icon-mouse-right:before {
    content: "\eabd"
}

.icon-keyboard:before {
    content: "\eabe"
}

.icon-typewriter:before {
    content: "\eabf"
}

.icon-display:before {
    content: "\eac0"
}

.icon-display4:before {
    content: "\eac1"
}

.icon-laptop:before {
    content: "\eac2"
}

.icon-mobile:before {
    content: "\eac3"
}

.icon-mobile2:before {
    content: "\eac4"
}

.icon-tablet:before {
    content: "\eac5"
}

.icon-mobile3:before {
    content: "\eac6"
}

.icon-tv:before {
    content: "\eac7"
}

.icon-radio:before {
    content: "\eac8"
}

.icon-cabinet:before {
    content: "\eac9"
}

.icon-drawer:before {
    content: "\eaca"
}

.icon-drawer2:before {
    content: "\eacb"
}

.icon-drawer-out:before {
    content: "\eacc"
}

.icon-drawer-in:before {
    content: "\eacd"
}

.icon-drawer3:before {
    content: "\eace"
}

.icon-box:before {
    content: "\eacf"
}

.icon-box-add:before {
    content: "\ead0"
}

.icon-box-remove:before {
    content: "\ead1"
}

.icon-download:before {
    content: "\ead2"
}

.icon-upload:before {
    content: "\ead3"
}

.icon-floppy-disk:before {
    content: "\ead4"
}

.icon-floppy-disks:before {
    content: "\ead5"
}

.icon-usb-stick:before {
    content: "\ead6"
}

.icon-drive:before {
    content: "\ead7"
}

.icon-server:before {
    content: "\ead8"
}

.icon-database:before {
    content: "\ead9"
}

.icon-database2:before {
    content: "\eada"
}

.icon-database4:before {
    content: "\eadb"
}

.icon-database-menu:before {
    content: "\eadc"
}

.icon-database-add:before {
    content: "\eadd"
}

.icon-database-remove:before {
    content: "\eade"
}

.icon-database-insert:before {
    content: "\eadf"
}

.icon-database-export:before {
    content: "\eae0"
}

.icon-database-upload:before {
    content: "\eae1"
}

.icon-database-refresh:before {
    content: "\eae2"
}

.icon-database-diff:before {
    content: "\eae3"
}

.icon-database-edit2:before {
    content: "\eae5"
}

.icon-database-check:before {
    content: "\eae6"
}

.icon-database-arrow:before {
    content: "\eae7"
}

.icon-database-time2:before {
    content: "\eae9"
}

.icon-undo:before {
    content: "\eaea"
}

.icon-redo:before {
    content: "\eaeb"
}

.icon-rotate-ccw:before {
    content: "\eaec"
}

.icon-rotate-cw:before {
    content: "\eaed"
}

.icon-rotate-ccw2:before {
    content: "\eaee"
}

.icon-rotate-cw2:before {
    content: "\eaef"
}

.icon-rotate-ccw3:before {
    content: "\eaf0"
}

.icon-rotate-cw3:before {
    content: "\eaf1"
}

.icon-flip-vertical2:before {
    content: "\eaf2"
}

.icon-flip-horizontal2:before {
    content: "\eaf3"
}

.icon-flip-vertical3:before {
    content: "\eaf4"
}

.icon-flip-vertical4:before {
    content: "\eaf5"
}

.icon-angle:before {
    content: "\eaf6"
}

.icon-shear:before {
    content: "\eaf7"
}

.icon-align-left:before {
    content: "\eafc"
}

.icon-align-center-horizontal:before {
    content: "\eafd"
}

.icon-align-right:before {
    content: "\eafe"
}

.icon-align-top:before {
    content: "\eaff"
}

.icon-align-center-vertical:before {
    content: "\eb00"
}

.icon-align-bottom:before {
    content: "\eb01"
}

.icon-undo2:before {
    content: "\eb02"
}

.icon-redo2:before {
    content: "\eb03"
}

.icon-forward:before {
    content: "\eb04"
}

.icon-reply:before {
    content: "\eb05"
}

.icon-reply-all:before {
    content: "\eb06"
}

.icon-bubble:before {
    content: "\eb07"
}

.icon-bubbles:before {
    content: "\eb08"
}

.icon-bubbles2:before {
    content: "\eb09"
}

.icon-bubble2:before {
    content: "\eb0a"
}

.icon-bubbles3:before {
    content: "\eb0b"
}

.icon-bubbles4:before {
    content: "\eb0c"
}

.icon-bubble-notification:before {
    content: "\eb0d"
}

.icon-bubbles5:before {
    content: "\eb0e"
}

.icon-bubbles6:before {
    content: "\eb0f"
}

.icon-bubble6:before {
    content: "\eb10"
}

.icon-bubbles7:before {
    content: "\eb11"
}

.icon-bubble7:before {
    content: "\eb12"
}

.icon-bubbles8:before {
    content: "\eb13"
}

.icon-bubble8:before {
    content: "\eb14"
}

.icon-bubble-dots3:before {
    content: "\eb15"
}

.icon-bubble-lines3:before {
    content: "\eb16"
}

.icon-bubble9:before {
    content: "\eb17"
}

.icon-bubble-dots4:before {
    content: "\eb18"
}

.icon-bubble-lines4:before {
    content: "\eb19"
}

.icon-bubbles9:before {
    content: "\eb1a"
}

.icon-bubbles10:before {
    content: "\eb1b"
}

.icon-user:before {
    content: "\eb33"
}

.icon-users:before {
    content: "\eb34"
}

.icon-user-plus:before {
    content: "\eb35"
}

.icon-user-minus:before {
    content: "\eb36"
}

.icon-user-cancel:before {
    content: "\eb37"
}

.icon-user-block:before {
    content: "\eb38"
}

.icon-user-lock:before {
    content: "\eb39"
}

.icon-user-check:before {
    content: "\eb3a"
}

.icon-users2:before {
    content: "\eb3b"
}

.icon-users4:before {
    content: "\eb44"
}

.icon-user-tie:before {
    content: "\eb45"
}

.icon-collaboration:before {
    content: "\eb46"
}

.icon-vcard:before {
    content: "\eb47"
}

.icon-hat:before {
    content: "\ebb8"
}

.icon-bowtie:before {
    content: "\ebb9"
}

.icon-quotes-left:before {
    content: "\eb49"
}

.icon-quotes-right:before {
    content: "\eb4a"
}

.icon-quotes-left2:before {
    content: "\eb4b"
}

.icon-quotes-right2:before {
    content: "\eb4c"
}

.icon-hour-glass:before {
    content: "\eb4d"
}

.icon-hour-glass2:before {
    content: "\eb4e"
}

.icon-hour-glass3:before {
    content: "\eb4f"
}

.icon-spinner:before {
    content: "\eb50"
}

.icon-spinner2:before {
    content: "\eb51"
}

.icon-spinner3:before {
    content: "\eb52"
}

.icon-spinner4:before {
    content: "\eb53"
}

.icon-spinner6:before {
    content: "\eb54"
}

.icon-spinner9:before {
    content: "\eb55"
}

.icon-spinner10:before {
    content: "\eb56"
}

.icon-spinner11:before {
    content: "\eb57"
}

.icon-microscope:before {
    content: "\eb58"
}

.icon-enlarge:before {
    content: "\eb59"
}

.icon-shrink:before {
    content: "\eb5a"
}

.icon-enlarge3:before {
    content: "\eb5b"
}

.icon-shrink3:before {
    content: "\eb5c"
}

.icon-enlarge5:before {
    content: "\eb5d"
}

.icon-shrink5:before {
    content: "\eb5e"
}

.icon-enlarge6:before {
    content: "\eb5f"
}

.icon-shrink6:before {
    content: "\eb60"
}

.icon-enlarge7:before {
    content: "\eb61"
}

.icon-shrink7:before {
    content: "\eb62"
}

.icon-key:before {
    content: "\eb63"
}

.icon-lock:before {
    content: "\eb65"
}

.icon-lock2:before {
    content: "\eb66"
}

.icon-lock4:before {
    content: "\eb67"
}

.icon-unlocked:before {
    content: "\eb68"
}

.icon-lock5:before {
    content: "\eb69"
}

.icon-unlocked2:before {
    content: "\eb6a"
}

.icon-safe:before {
    content: "\eb6b"
}

.icon-wrench:before {
    content: "\eb6c"
}

.icon-wrench2:before {
    content: "\eb6d"
}

.icon-wrench3:before {
    content: "\eb6e"
}

.icon-equalizer:before {
    content: "\eb6f"
}

.icon-equalizer2:before {
    content: "\eb70"
}

.icon-equalizer3:before {
    content: "\eb71"
}

.icon-equalizer4:before {
    content: "\eb72"
}

.icon-cog:before {
    content: "\eb73"
}

.icon-cogs:before {
    content: "\eb74"
}

.icon-cog2:before {
    content: "\eb75"
}

.icon-cog3:before {
    content: "\eb76"
}

.icon-cog4:before {
    content: "\eb77"
}

.icon-cog52:before {
    content: "\eb78"
}

.icon-cog6:before {
    content: "\eb79"
}

.icon-cog7:before {
    content: "\eb7a"
}

.icon-hammer:before {
    content: "\eb7c"
}

.icon-hammer-wrench:before {
    content: "\eb7d"
}

.icon-magic-wand:before {
    content: "\eb7e"
}

.icon-magic-wand2:before {
    content: "\eb7f"
}

.icon-pulse2:before {
    content: "\eb80"
}

.icon-aid-kit:before {
    content: "\eb81"
}

.icon-bug2:before {
    content: "\eb83"
}

.icon-construction:before {
    content: "\eb85"
}

.icon-traffic-cone:before {
    content: "\eb86"
}

.icon-traffic-lights:before {
    content: "\eb87"
}

.icon-pie-chart:before {
    content: "\eb88"
}

.icon-pie-chart2:before {
    content: "\eb89"
}

.icon-pie-chart3:before {
    content: "\eb8a"
}

.icon-pie-chart4:before {
    content: "\eb8b"
}

.icon-pie-chart5:before {
    content: "\eb8c"
}

.icon-pie-chart6:before {
    content: "\eb8d"
}

.icon-pie-chart7:before {
    content: "\eb8e"
}

.icon-stats-dots:before {
    content: "\eb8f"
}

.icon-stats-bars:before {
    content: "\eb90"
}

.icon-pie-chart8:before {
    content: "\eb91"
}

.icon-stats-bars2:before {
    content: "\eb92"
}

.icon-stats-bars3:before {
    content: "\eb93"
}

.icon-stats-bars4:before {
    content: "\eb94"
}

.icon-chart:before {
    content: "\eb97"
}

.icon-stats-growth:before {
    content: "\eb98"
}

.icon-stats-decline:before {
    content: "\eb99"
}

.icon-stats-growth2:before {
    content: "\eb9a"
}

.icon-stats-decline2:before {
    content: "\eb9b"
}

.icon-stairs-up:before {
    content: "\eb9c"
}

.icon-stairs-down:before {
    content: "\eb9d"
}

.icon-stairs:before {
    content: "\eb9e"
}

.icon-ladder:before {
    content: "\eba0"
}

.icon-rating:before {
    content: "\eba1"
}

.icon-rating2:before {
    content: "\eba2"
}

.icon-rating3:before {
    content: "\eba3"
}

.icon-podium:before {
    content: "\eba5"
}

.icon-stars:before {
    content: "\eba6"
}

.icon-medal-star:before {
    content: "\eba7"
}

.icon-medal:before {
    content: "\eba8"
}

.icon-medal2:before {
    content: "\eba9"
}

.icon-medal-first:before {
    content: "\ebaa"
}

.icon-medal-second:before {
    content: "\ebab"
}

.icon-medal-third:before {
    content: "\ebac"
}

.icon-crown:before {
    content: "\ebad"
}

.icon-trophy2:before {
    content: "\ebaf"
}

.icon-trophy3:before {
    content: "\ebb0"
}

.icon-diamond:before {
    content: "\ebb1"
}

.icon-trophy4:before {
    content: "\ebb2"
}

.icon-gift:before {
    content: "\ebb3"
}

.icon-pipe:before {
    content: "\ebb6"
}

.icon-mustache:before {
    content: "\ebb7"
}

.icon-cup2:before {
    content: "\ebc6"
}

.icon-coffee:before {
    content: "\ebc8"
}

.icon-paw:before {
    content: "\ebd5"
}

.icon-footprint:before {
    content: "\ebd6"
}

.icon-rocket:before {
    content: "\ebda"
}

.icon-meter2:before {
    content: "\ebdc"
}

.icon-meter-slow:before {
    content: "\ebdd"
}

.icon-meter-fast:before {
    content: "\ebdf"
}

.icon-hammer2:before {
    content: "\ebe1"
}

.icon-balance:before {
    content: "\ebe2"
}

.icon-fire:before {
    content: "\ebe5"
}

.icon-fire2:before {
    content: "\ebe6"
}

.icon-lab:before {
    content: "\ebe7"
}

.icon-atom:before {
    content: "\ebe8"
}

.icon-atom2:before {
    content: "\ebe9"
}

.icon-bin:before {
    content: "\ebfa"
}

.icon-bin2:before {
    content: "\ebfb"
}

.icon-briefcase:before {
    content: "\ebff"
}

.icon-briefcase3:before {
    content: "\ec01"
}

.icon-airplane2:before {
    content: "\ec03"
}

.icon-airplane3:before {
    content: "\ec04"
}

.icon-airplane4:before {
    content: "\ec05"
}

.icon-paperplane:before {
    content: "\ec06"
}

.icon-car:before {
    content: "\ec07"
}

.icon-steering-wheel:before {
    content: "\ec08"
}

.icon-car2:before {
    content: "\ec09"
}

.icon-gas:before {
    content: "\ec0a"
}

.icon-bus:before {
    content: "\ec0b"
}

.icon-truck:before {
    content: "\ec0c"
}

.icon-bike:before {
    content: "\ec0d"
}

.icon-road:before {
    content: "\ec0e"
}

.icon-train:before {
    content: "\ec0f"
}

.icon-train2:before {
    content: "\ec10"
}

.icon-ship:before {
    content: "\ec11"
}

.icon-boat:before {
    content: "\ec12"
}

.icon-chopper:before {
    content: "\ec13"
}

.icon-cube:before {
    content: "\ec15"
}

.icon-cube2:before {
    content: "\ec16"
}

.icon-cube3:before {
    content: "\ec17"
}

.icon-cube4:before {
    content: "\ec18"
}

.icon-pyramid:before {
    content: "\ec19"
}

.icon-pyramid2:before {
    content: "\ec1a"
}

.icon-package:before {
    content: "\ec1b"
}

.icon-puzzle:before {
    content: "\ec1c"
}

.icon-puzzle2:before {
    content: "\ec1d"
}

.icon-puzzle3:before {
    content: "\ec1e"
}

.icon-puzzle4:before {
    content: "\ec1f"
}

.icon-glasses-3d2:before {
    content: "\ec21"
}

.icon-brain:before {
    content: "\ec24"
}

.icon-accessibility:before {
    content: "\ec25"
}

.icon-accessibility2:before {
    content: "\ec26"
}

.icon-strategy:before {
    content: "\ec27"
}

.icon-target:before {
    content: "\ec28"
}

.icon-target2:before {
    content: "\ec29"
}

.icon-shield-check:before {
    content: "\ec2f"
}

.icon-shield-notice:before {
    content: "\ec30"
}

.icon-shield2:before {
    content: "\ec31"
}

.icon-racing:before {
    content: "\ec40"
}

.icon-finish:before {
    content: "\ec41"
}

.icon-power2:before {
    content: "\ec46"
}

.icon-power3:before {
    content: "\ec47"
}

.icon-switch:before {
    content: "\ec48"
}

.icon-switch22:before {
    content: "\ec49"
}

.icon-power-cord:before {
    content: "\ec4a"
}

.icon-clipboard:before {
    content: "\ec4d"
}

.icon-clipboard2:before {
    content: "\ec4e"
}

.icon-clipboard3:before {
    content: "\ec4f"
}

.icon-clipboard4:before {
    content: "\ec50"
}

.icon-clipboard5:before {
    content: "\ec51"
}

.icon-clipboard6:before {
    content: "\ec52"
}

.icon-playlist:before {
    content: "\ec53"
}

.icon-playlist-add:before {
    content: "\ec54"
}

.icon-list-numbered:before {
    content: "\ec55"
}

.icon-list:before {
    content: "\ec56"
}

.icon-list2:before {
    content: "\ec57"
}

.icon-more:before {
    content: "\ec58"
}

.icon-more2:before {
    content: "\ec59"
}

.icon-grid:before {
    content: "\ec5a"
}

.icon-grid2:before {
    content: "\ec5b"
}

.icon-grid3:before {
    content: "\ec5c"
}

.icon-grid4:before {
    content: "\ec5d"
}

.icon-grid52:before {
    content: "\ec5e"
}

.icon-grid6:before {
    content: "\ec5f"
}

.icon-grid7:before {
    content: "\ec60"
}

.icon-tree5:before {
    content: "\ec61"
}

.icon-tree6:before {
    content: "\ec62"
}

.icon-tree7:before {
    content: "\ec63"
}

.icon-lan:before {
    content: "\ec64"
}

.icon-lan2:before {
    content: "\ec65"
}

.icon-lan3:before {
    content: "\ec66"
}

.icon-menu:before {
    content: "\ec67"
}

.icon-circle-small:before {
    content: "\ec68"
}

.icon-menu2:before {
    content: "\ec69"
}

.icon-menu3:before {
    content: "\ec6a"
}

.icon-menu4:before {
    content: "\ec6b"
}

.icon-menu5:before {
    content: "\ec6c"
}

.icon-menu62:before {
    content: "\ec6d"
}

.icon-menu7:before {
    content: "\ec6e"
}

.icon-menu8:before {
    content: "\ec6f"
}

.icon-menu9:before {
    content: "\ec70"
}

.icon-menu10:before {
    content: "\ec71"
}

.icon-cloud:before {
    content: "\ec72"
}

.icon-cloud-download:before {
    content: "\ec73"
}

.icon-cloud-upload:before {
    content: "\ec74"
}

.icon-cloud-check:before {
    content: "\ec75"
}

.icon-cloud2:before {
    content: "\ec76"
}

.icon-cloud-download2:before {
    content: "\ec77"
}

.icon-cloud-upload2:before {
    content: "\ec78"
}

.icon-cloud-check2:before {
    content: "\ec79"
}

.icon-import:before {
    content: "\ec7e"
}

.icon-download4:before {
    content: "\ec80"
}

.icon-upload4:before {
    content: "\ec81"
}

.icon-download7:before {
    content: "\ec86"
}

.icon-upload7:before {
    content: "\ec87"
}

.icon-download10:before {
    content: "\ec8c"
}

.icon-upload10:before {
    content: "\ec8d"
}

.icon-sphere:before {
    content: "\ec8e"
}

.icon-sphere3:before {
    content: "\ec90"
}

.icon-earth:before {
    content: "\ec93"
}

.icon-link:before {
    content: "\ec96"
}

.icon-unlink:before {
    content: "\ec97"
}

.icon-link2:before {
    content: "\ec98"
}

.icon-unlink2:before {
    content: "\ec99"
}

.icon-anchor:before {
    content: "\eca0"
}

.icon-flag3:before {
    content: "\eca3"
}

.icon-flag4:before {
    content: "\eca4"
}

.icon-flag7:before {
    content: "\eca7"
}

.icon-flag8:before {
    content: "\eca8"
}

.icon-attachment:before {
    content: "\eca9"
}

.icon-attachment2:before {
    content: "\ecaa"
}

.icon-eye:before {
    content: "\ecab"
}

.icon-eye-plus:before {
    content: "\ecac"
}

.icon-eye-minus:before {
    content: "\ecad"
}

.icon-eye-blocked:before {
    content: "\ecae"
}

.icon-eye2:before {
    content: "\ecaf"
}

.icon-eye-blocked2:before {
    content: "\ecb0"
}

.icon-eye4:before {
    content: "\ecb3"
}

.icon-bookmark2:before {
    content: "\ecb4"
}

.icon-bookmark3:before {
    content: "\ecb5"
}

.icon-bookmarks:before {
    content: "\ecb6"
}

.icon-bookmark4:before {
    content: "\ecb7"
}

.icon-spotlight2:before {
    content: "\ecb8"
}

.icon-starburst:before {
    content: "\ecb9"
}

.icon-snowflake:before {
    content: "\ecba"
}

.icon-weather-windy:before {
    content: "\ecd0"
}

.icon-fan:before {
    content: "\ecd1"
}

.icon-umbrella:before {
    content: "\ecd2"
}

.icon-sun3:before {
    content: "\ecd3"
}

.icon-contrast:before {
    content: "\ecd4"
}

.icon-bed2:before {
    content: "\ecda"
}

.icon-furniture:before {
    content: "\ecdb"
}

.icon-chair:before {
    content: "\ecdc"
}

.icon-star-empty3:before {
    content: "\ece0"
}

.icon-star-half:before {
    content: "\ece1"
}

.icon-star-full2:before {
    content: "\ece2"
}

.icon-heart5:before {
    content: "\ece9"
}

.icon-heart6:before {
    content: "\ecea"
}

.icon-heart-broken2:before {
    content: "\eceb"
}

.icon-thumbs-up2:before {
    content: "\ecf2"
}

.icon-thumbs-down2:before {
    content: "\ecf4"
}

.icon-thumbs-up3:before {
    content: "\ecf5"
}

.icon-thumbs-down3:before {
    content: "\ecf6"
}

.icon-height:before {
    content: "\ecf7"
}

.icon-man:before {
    content: "\ecf8"
}

.icon-woman:before {
    content: "\ecf9"
}

.icon-man-woman:before {
    content: "\ecfa"
}

.icon-yin-yang:before {
    content: "\ecfe"
}

.icon-cursor:before {
    content: "\ed23"
}

.icon-cursor2:before {
    content: "\ed24"
}

.icon-lasso2:before {
    content: "\ed26"
}

.icon-select2:before {
    content: "\ed28"
}

.icon-point-up:before {
    content: "\ed29"
}

.icon-point-right:before {
    content: "\ed2a"
}

.icon-point-down:before {
    content: "\ed2b"
}

.icon-point-left:before {
    content: "\ed2c"
}

.icon-pointer:before {
    content: "\ed2d"
}

.icon-reminder:before {
    content: "\ed2e"
}

.icon-drag-left-right:before {
    content: "\ed2f"
}

.icon-drag-left:before {
    content: "\ed30"
}

.icon-drag-right:before {
    content: "\ed31"
}

.icon-touch:before {
    content: "\ed32"
}

.icon-multitouch:before {
    content: "\ed33"
}

.icon-touch-zoom:before {
    content: "\ed34"
}

.icon-touch-pinch:before {
    content: "\ed35"
}

.icon-hand:before {
    content: "\ed36"
}

.icon-grab:before {
    content: "\ed37"
}

.icon-stack-empty:before {
    content: "\ed38"
}

.icon-stack-plus:before {
    content: "\ed39"
}

.icon-stack-minus:before {
    content: "\ed3a"
}

.icon-stack-star:before {
    content: "\ed3b"
}

.icon-stack-picture:before {
    content: "\ed3c"
}

.icon-stack-down:before {
    content: "\ed3d"
}

.icon-stack-up:before {
    content: "\ed3e"
}

.icon-stack-cancel:before {
    content: "\ed3f"
}

.icon-stack-check:before {
    content: "\ed40"
}

.icon-stack-text:before {
    content: "\ed41"
}

.icon-stack4:before {
    content: "\ed47"
}

.icon-stack-music:before {
    content: "\ed48"
}

.icon-stack-play:before {
    content: "\ed49"
}

.icon-move:before {
    content: "\ed4a"
}

.icon-dots:before {
    content: "\ed4b"
}

.icon-warning:before {
    content: "\ed4c"
}

.icon-warning22:before {
    content: "\ed4d"
}

.icon-notification2:before {
    content: "\ed4f"
}

.icon-question3:before {
    content: "\ed52"
}

.icon-question4:before {
    content: "\ed53"
}

.icon-plus3:before {
    content: "\ed5a"
}

.icon-minus3:before {
    content: "\ed5b"
}

.icon-plus-circle2:before {
    content: "\ed5e"
}

.icon-minus-circle2:before {
    content: "\ed5f"
}

.icon-cancel-circle2:before {
    content: "\ed63"
}

.icon-blocked:before {
    content: "\ed64"
}

.icon-cancel-square:before {
    content: "\ed65"
}

.icon-cancel-square2:before {
    content: "\ed66"
}

.icon-spam:before {
    content: "\ed68"
}

.icon-cross2:before {
    content: "\ed6a"
}

.icon-cross3:before {
    content: "\ed6b"
}

.icon-checkmark:before {
    content: "\ed6c"
}

.icon-checkmark3:before {
    content: "\ed6e"
}

.icon-checkmark2:before {
    content: "\e372"
}

.icon-checkmark4:before {
    content: "\ed6f"
}

.icon-spell-check:before {
    content: "\ed71"
}

.icon-spell-check2:before {
    content: "\ed72"
}

.icon-enter:before {
    content: "\ed73"
}

.icon-exit:before {
    content: "\ed74"
}

.icon-enter2:before {
    content: "\ed75"
}

.icon-exit2:before {
    content: "\ed76"
}

.icon-enter3:before {
    content: "\ed77"
}

.icon-exit3:before {
    content: "\ed78"
}

.icon-wall:before {
    content: "\ed79"
}

.icon-fence:before {
    content: "\ed7a"
}

.icon-play3:before {
    content: "\ed7b"
}

.icon-pause:before {
    content: "\ed7c"
}

.icon-stop:before {
    content: "\ed7d"
}

.icon-previous:before {
    content: "\ed7e"
}

.icon-next:before {
    content: "\ed7f"
}

.icon-backward:before {
    content: "\ed80"
}

.icon-forward2:before {
    content: "\ed81"
}

.icon-play4:before {
    content: "\ed82"
}

.icon-pause2:before {
    content: "\ed83"
}

.icon-stop2:before {
    content: "\ed84"
}

.icon-backward2:before {
    content: "\ed85"
}

.icon-forward3:before {
    content: "\ed86"
}

.icon-first:before {
    content: "\ed87"
}

.icon-last:before {
    content: "\ed88"
}

.icon-previous2:before {
    content: "\ed89"
}

.icon-next2:before {
    content: "\ed8a"
}

.icon-eject:before {
    content: "\ed8b"
}

.icon-volume-high:before {
    content: "\ed8c"
}

.icon-volume-medium:before {
    content: "\ed8d"
}

.icon-volume-low:before {
    content: "\ed8e"
}

.icon-volume-mute:before {
    content: "\ed8f"
}

.icon-speaker-left:before {
    content: "\ed90"
}

.icon-speaker-right:before {
    content: "\ed91"
}

.icon-volume-mute2:before {
    content: "\ed92"
}

.icon-volume-increase:before {
    content: "\ed93"
}

.icon-volume-decrease:before {
    content: "\ed94"
}

.icon-volume-mute5:before {
    content: "\eda4"
}

.icon-loop:before {
    content: "\eda5"
}

.icon-loop3:before {
    content: "\eda7"
}

.icon-infinite-square:before {
    content: "\eda8"
}

.icon-infinite:before {
    content: "\eda9"
}

.icon-loop4:before {
    content: "\edab"
}

.icon-shuffle:before {
    content: "\edac"
}

.icon-wave:before {
    content: "\edae"
}

.icon-wave2:before {
    content: "\edaf"
}

.icon-split:before {
    content: "\edb0"
}

.icon-merge:before {
    content: "\edb1"
}

.icon-arrow-up5:before {
    content: "\edc4"
}

.icon-arrow-right5:before {
    content: "\edc5"
}

.icon-arrow-down5:before {
    content: "\edc6"
}

.icon-arrow-left5:before {
    content: "\edc7"
}

.icon-arrow-up-left2:before {
    content: "\edd0"
}

.icon-arrow-up7:before {
    content: "\edd1"
}

.icon-arrow-up-right2:before {
    content: "\edd2"
}

.icon-arrow-right7:before {
    content: "\edd3"
}

.icon-arrow-down-right2:before {
    content: "\edd4"
}

.icon-arrow-down7:before {
    content: "\edd5"
}

.icon-arrow-down-left2:before {
    content: "\edd6"
}

.icon-arrow-left7:before {
    content: "\edd7"
}

.icon-arrow-up-left3:before {
    content: "\edd8"
}

.icon-arrow-up8:before {
    content: "\edd9"
}

.icon-arrow-up-right3:before {
    content: "\edda"
}

.icon-arrow-right8:before {
    content: "\eddb"
}

.icon-arrow-down-right3:before {
    content: "\eddc"
}

.icon-arrow-down8:before {
    content: "\eddd"
}

.icon-arrow-down-left3:before {
    content: "\edde"
}

.icon-arrow-left8:before {
    content: "\eddf"
}

.icon-circle-up2:before {
    content: "\ede4"
}

.icon-circle-right2:before {
    content: "\ede5"
}

.icon-circle-down2:before {
    content: "\ede6"
}

.icon-circle-left2:before {
    content: "\ede7"
}

.icon-arrow-resize7:before {
    content: "\edfe"
}

.icon-arrow-resize8:before {
    content: "\edff"
}

.icon-square-up-left:before {
    content: "\ee00"
}

.icon-square-up:before {
    content: "\ee01"
}

.icon-square-up-right:before {
    content: "\ee02"
}

.icon-square-right:before {
    content: "\ee03"
}

.icon-square-down-right:before {
    content: "\ee04"
}

.icon-square-down:before {
    content: "\ee05"
}

.icon-square-down-left:before {
    content: "\ee06"
}

.icon-square-left:before {
    content: "\ee07"
}

.icon-arrow-up15:before {
    content: "\ee30"
}

.icon-arrow-right15:before {
    content: "\ee31"
}

.icon-arrow-down15:before {
    content: "\ee32"
}

.icon-arrow-left15:before {
    content: "\ee33"
}

.icon-arrow-up16:before {
    content: "\ee34"
}

.icon-arrow-right16:before {
    content: "\ee35"
}

.icon-arrow-down16:before {
    content: "\ee36"
}

.icon-arrow-left16:before {
    content: "\ee37"
}

.icon-menu-open:before {
    content: "\ee38"
}

.icon-menu-open2:before {
    content: "\ee39"
}

.icon-menu-close:before {
    content: "\ee3a"
}

.icon-menu-close2:before {
    content: "\ee3b"
}

.icon-enter5:before {
    content: "\ee3d"
}

.icon-esc:before {
    content: "\ee3e"
}

.icon-enter6:before {
    content: "\ee3f"
}

.icon-backspace:before {
    content: "\ee40"
}

.icon-backspace2:before {
    content: "\ee41"
}

.icon-tab:before {
    content: "\ee42"
}

.icon-transmission:before {
    content: "\ee43"
}

.icon-sort:before {
    content: "\ee45"
}

.icon-move-up2:before {
    content: "\ee47"
}

.icon-move-down2:before {
    content: "\ee48"
}

.icon-sort-alpha-asc:before {
    content: "\ee49"
}

.icon-sort-alpha-desc:before {
    content: "\ee4a"
}

.icon-sort-numeric-asc:before {
    content: "\ee4b"
}

.icon-sort-numberic-desc:before {
    content: "\ee4c"
}

.icon-sort-amount-asc:before {
    content: "\ee4d"
}

.icon-sort-amount-desc:before {
    content: "\ee4e"
}

.icon-sort-time-asc:before {
    content: "\ee4f"
}

.icon-sort-time-desc:before {
    content: "\ee50"
}

.icon-battery-6:before {
    content: "\ee51"
}

.icon-battery-0:before {
    content: "\ee57"
}

.icon-battery-charging:before {
    content: "\ee58"
}

.icon-command:before {
    content: "\ee5f"
}

.icon-shift:before {
    content: "\ee60"
}

.icon-ctrl:before {
    content: "\ee61"
}

.icon-opt:before {
    content: "\ee62"
}

.icon-checkbox-checked:before {
    content: "\ee63"
}

.icon-checkbox-unchecked:before {
    content: "\ee64"
}

.icon-checkbox-partial:before {
    content: "\ee65"
}

.icon-square:before {
    content: "\ee66"
}

.icon-triangle:before {
    content: "\ee67"
}

.icon-triangle2:before {
    content: "\ee68"
}

.icon-diamond3:before {
    content: "\ee69"
}

.icon-diamond4:before {
    content: "\ee6a"
}

.icon-checkbox-checked2:before {
    content: "\ee6b"
}

.icon-checkbox-unchecked2:before {
    content: "\ee6c"
}

.icon-checkbox-partial2:before {
    content: "\ee6d"
}

.icon-radio-checked:before {
    content: "\ee6e"
}

.icon-radio-checked2:before {
    content: "\ee6f"
}

.icon-radio-unchecked:before {
    content: "\ee70"
}

.icon-checkmark-circle:before {
    content: "\ee73"
}

.icon-circle:before {
    content: "\ee74"
}

.icon-circle2:before {
    content: "\ee75"
}

.icon-circles:before {
    content: "\ee76"
}

.icon-circles2:before {
    content: "\ee77"
}

.icon-crop:before {
    content: "\ee78"
}

.icon-crop2:before {
    content: "\ee79"
}

.icon-make-group:before {
    content: "\ee7a"
}

.icon-ungroup:before {
    content: "\ee7b"
}

.icon-vector:before {
    content: "\ee7c"
}

.icon-vector2:before {
    content: "\ee7d"
}

.icon-rulers:before {
    content: "\ee7e"
}

.icon-pencil-ruler:before {
    content: "\ee80"
}

.icon-scissors:before {
    content: "\ee81"
}

.icon-filter3:before {
    content: "\ee88"
}

.icon-filter4:before {
    content: "\ee89"
}

.icon-font:before {
    content: "\ee8a"
}

.icon-ampersand2:before {
    content: "\ee8b"
}

.icon-ligature:before {
    content: "\ee8c"
}

.icon-font-size:before {
    content: "\ee8e"
}

.icon-typography:before {
    content: "\ee8f"
}

.icon-text-height:before {
    content: "\ee90"
}

.icon-text-width:before {
    content: "\ee91"
}

.icon-height2:before {
    content: "\ee92"
}

.icon-width:before {
    content: "\ee93"
}

.icon-strikethrough2:before {
    content: "\ee98"
}

.icon-font-size2:before {
    content: "\ee99"
}

.icon-bold2:before {
    content: "\ee9a"
}

.icon-underline2:before {
    content: "\ee9b"
}

.icon-italic2:before {
    content: "\ee9c"
}

.icon-strikethrough3:before {
    content: "\ee9d"
}

.icon-omega:before {
    content: "\ee9e"
}

.icon-sigma:before {
    content: "\ee9f"
}

.icon-nbsp:before {
    content: "\eea0"
}

.icon-page-break:before {
    content: "\eea1"
}

.icon-page-break2:before {
    content: "\eea2"
}

.icon-superscript:before {
    content: "\eea3"
}

.icon-subscript:before {
    content: "\eea4"
}

.icon-superscript2:before {
    content: "\eea5"
}

.icon-subscript2:before {
    content: "\eea6"
}

.icon-text-color:before {
    content: "\eea7"
}

.icon-highlight:before {
    content: "\eea8"
}

.icon-pagebreak:before {
    content: "\eea9"
}

.icon-clear-formatting:before {
    content: "\eeaa"
}

.icon-table:before {
    content: "\eeab"
}

.icon-table2:before {
    content: "\eeac"
}

.icon-insert-template:before {
    content: "\eead"
}

.icon-pilcrow:before {
    content: "\eeae"
}

.icon-ltr:before {
    content: "\eeaf"
}

.icon-rtl:before {
    content: "\eeb0"
}

.icon-ltr2:before {
    content: "\eeb1"
}

.icon-rtl2:before {
    content: "\eeb2"
}

.icon-section:before {
    content: "\eeb3"
}

.icon-paragraph-left2:before {
    content: "\eeb8"
}

.icon-paragraph-center2:before {
    content: "\eeb9"
}

.icon-paragraph-right2:before {
    content: "\eeba"
}

.icon-paragraph-justify2:before {
    content: "\eebb"
}

.icon-indent-increase:before {
    content: "\eebc"
}

.icon-indent-decrease:before {
    content: "\eebd"
}

.icon-paragraph-left3:before {
    content: "\eebe"
}

.icon-paragraph-center3:before {
    content: "\eebf"
}

.icon-paragraph-right3:before {
    content: "\eec0"
}

.icon-paragraph-justify3:before {
    content: "\eec1"
}

.icon-indent-increase2:before {
    content: "\eec2"
}

.icon-indent-decrease2:before {
    content: "\eec3"
}

.icon-share:before {
    content: "\eec4"
}

.icon-share2:before {
    content: "\eec5"
}

.icon-new-tab:before {
    content: "\eec6"
}

.icon-new-tab2:before {
    content: "\eec7"
}

.icon-popout:before {
    content: "\eec8"
}

.icon-embed:before {
    content: "\eec9"
}

.icon-embed2:before {
    content: "\eeca"
}

.icon-markup:before {
    content: "\eecb"
}

.icon-regexp:before {
    content: "\eecc"
}

.icon-regexp2:before {
    content: "\eecd"
}

.icon-code:before {
    content: "\eece"
}

.icon-circle-css:before {
    content: "\eecf"
}

.icon-circle-code:before {
    content: "\eed0"
}

.icon-terminal:before {
    content: "\eed1"
}

.icon-unicode:before {
    content: "\eed2"
}

.icon-seven-segment-0:before {
    content: "\eed3"
}

.icon-seven-segment-1:before {
    content: "\eed4"
}

.icon-seven-segment-2:before {
    content: "\eed5"
}

.icon-seven-segment-3:before {
    content: "\eed6"
}

.icon-seven-segment-4:before {
    content: "\eed7"
}

.icon-seven-segment-5:before {
    content: "\eed8"
}

.icon-seven-segment-6:before {
    content: "\eed9"
}

.icon-seven-segment-7:before {
    content: "\eeda"
}

.icon-seven-segment-8:before {
    content: "\eedb"
}

.icon-seven-segment-9:before {
    content: "\eedc"
}

.icon-share3:before {
    content: "\eedd"
}

.icon-share4:before {
    content: "\eede"
}

.icon-google:before {
    content: "\eee3"
}

.icon-google-plus:before {
    content: "\eee4"
}

.icon-google-plus2:before {
    content: "\eee5"
}

.icon-google-drive:before {
    content: "\eee7"
}

.icon-facebook:before {
    content: "\eee8"
}

.icon-facebook2:before {
    content: "\eee9"
}

.icon-instagram:before {
    content: "\eeec"
}

.icon-twitter:before {
    content: "\eeed"
}

.icon-twitter2:before {
    content: "\eeee"
}

.icon-feed2:before {
    content: "\eef0"
}

.icon-feed3:before {
    content: "\eef1"
}

.icon-youtube:before {
    content: "\eef3"
}

.icon-youtube2:before {
    content: "\eef4"
}

.icon-youtube3:before {
    content: "\eef5"
}

.icon-vimeo:before {
    content: "\eef8"
}

.icon-vimeo2:before {
    content: "\eef9"
}

.icon-lanyrd:before {
    content: "\eefb"
}

.icon-flickr:before {
    content: "\eefc"
}

.icon-flickr2:before {
    content: "\eefd"
}

.icon-flickr3:before {
    content: "\eefe"
}

.icon-picassa:before {
    content: "\ef00"
}

.icon-picassa2:before {
    content: "\ef01"
}

.icon-dribbble:before {
    content: "\ef02"
}

.icon-dribbble2:before {
    content: "\ef03"
}

.icon-dribbble3:before {
    content: "\ef04"
}

.icon-forrst:before {
    content: "\ef05"
}

.icon-forrst2:before {
    content: "\ef06"
}

.icon-deviantart:before {
    content: "\ef07"
}

.icon-deviantart2:before {
    content: "\ef08"
}

.icon-steam:before {
    content: "\ef09"
}

.icon-steam2:before {
    content: "\ef0a"
}

.icon-dropbox:before {
    content: "\ef0b"
}

.icon-onedrive:before {
    content: "\ef0c"
}

.icon-github:before {
    content: "\ef0d"
}

.icon-github4:before {
    content: "\ef10"
}

.icon-github5:before {
    content: "\ef11"
}

.icon-wordpress:before {
    content: "\ef12"
}

.icon-wordpress2:before {
    content: "\ef13"
}

.icon-joomla:before {
    content: "\ef14"
}

.icon-blogger:before {
    content: "\ef15"
}

.icon-blogger2:before {
    content: "\ef16"
}

.icon-tumblr:before {
    content: "\ef17"
}

.icon-tumblr2:before {
    content: "\ef18"
}

.icon-yahoo:before {
    content: "\ef19"
}

.icon-tux:before {
    content: "\ef1a"
}

.icon-apple2:before {
    content: "\ef1b"
}

.icon-finder:before {
    content: "\ef1c"
}

.icon-android:before {
    content: "\ef1d"
}

.icon-windows:before {
    content: "\ef1e"
}

.icon-windows8:before {
    content: "\ef1f"
}

.icon-soundcloud:before {
    content: "\ef20"
}

.icon-soundcloud2:before {
    content: "\ef21"
}

.icon-skype:before {
    content: "\ef22"
}

.icon-reddit:before {
    content: "\ef23"
}

.icon-linkedin:before {
    content: "\ef24"
}

.icon-linkedin2:before {
    content: "\ef25"
}

.icon-lastfm:before {
    content: "\ef26"
}

.icon-lastfm2:before {
    content: "\ef27"
}

.icon-delicious:before {
    content: "\ef28"
}

.icon-stumbleupon:before {
    content: "\ef29"
}

.icon-stumbleupon2:before {
    content: "\ef2a"
}

.icon-stackoverflow:before {
    content: "\ef2b"
}

.icon-pinterest2:before {
    content: "\ef2d"
}

.icon-xing:before {
    content: "\ef2e"
}

.icon-flattr:before {
    content: "\ef30"
}

.icon-foursquare:before {
    content: "\ef31"
}

.icon-paypal:before {
    content: "\ef32"
}

.icon-paypal2:before {
    content: "\ef33"
}

.icon-yelp:before {
    content: "\ef35"
}

.icon-file-pdf:before {
    content: "\ef36"
}

.icon-file-openoffice:before {
    content: "\ef37"
}

.icon-file-word:before {
    content: "\ef38"
}

.icon-file-excel:before {
    content: "\ef39"
}

.icon-libreoffice:before {
    content: "\ef3a"
}

.icon-html5:before {
    content: "\ef3b"
}

.icon-html52:before {
    content: "\ef3c"
}

.icon-css3:before {
    content: "\ef3d"
}

.icon-git:before {
    content: "\ef3e"
}

.icon-svg:before {
    content: "\ef3f"
}

.icon-codepen:before {
    content: "\ef40"
}

.icon-chrome:before {
    content: "\ef41"
}

.icon-firefox:before {
    content: "\ef42"
}

.icon-IE:before {
    content: "\ef43"
}

.icon-opera:before {
    content: "\ef44"
}

.icon-safari:before {
    content: "\ef45"
}

.icon-check2:before {
    content: "\e601"
}

.icon-home4:before {
    content: "\e603"
}

.icon-people:before {
    content: "\e81b"
}

.icon-checkmark-circle2:before {
    content: "\e853"
}

.icon-arrow-up-left32:before {
    content: "\e8ae"
}

.icon-arrow-up52:before {
    content: "\e8af"
}

.icon-arrow-up-right32:before {
    content: "\e8b0"
}

.icon-arrow-right6:before {
    content: "\e8b1"
}

.icon-arrow-down-right32:before {
    content: "\e8b2"
}

.icon-arrow-down52:before {
    content: "\e8b3"
}

.icon-arrow-down-left32:before {
    content: "\e8b4"
}

.icon-arrow-left52:before {
    content: "\e8b5"
}

.icon-calendar5:before {
    content: "\e985"
}

.icon-move-alt1:before {
    content: "\e986"
}

.icon-reload-alt:before {
    content: "\e987"
}

.icon-move-vertical:before {
    content: "\e988"
}

.icon-move-horizontal:before {
    content: "\e989"
}

.icon-hash:before {
    content: "\e98b"
}

.icon-bars-alt:before {
    content: "\e98c"
}

.icon-eye8:before {
    content: "\e98d"
}

.icon-search4:before {
    content: "\e98e"
}

.icon-zoomin3:before {
    content: "\e98f"
}

.icon-zoomout3:before {
    content: "\e990"
}

.icon-add:before {
    content: "\e991"
}

.icon-subtract:before {
    content: "\e992"
}

.icon-exclamation:before {
    content: "\e993"
}

.icon-question6:before {
    content: "\e994"
}

.icon-close2:before {
    content: "\e995"
}

.icon-task:before {
    content: "\e996"
}

.icon-inbox:before {
    content: "\e997"
}

.icon-inbox-alt:before {
    content: "\e998"
}

.icon-envelope:before {
    content: "\e999"
}

.icon-compose:before {
    content: "\e99a"
}

.icon-newspaper2:before {
    content: "\e99b"
}

.icon-calendar22:before {
    content: "\e99c"
}

.icon-hyperlink:before {
    content: "\e99d"
}

.icon-trash:before {
    content: "\e99e"
}

.icon-trash-alt:before {
    content: "\e99f"
}

.icon-grid5:before {
    content: "\e9a0"
}

.icon-grid-alt:before {
    content: "\e9a1"
}

.icon-menu6:before {
    content: "\e9a2"
}

.icon-list3:before {
    content: "\e9a3"
}

.icon-gallery:before {
    content: "\e9a4"
}

.icon-calculator:before {
    content: "\e9a5"
}

.icon-windows2:before {
    content: "\e9a6"
}

.icon-browser:before {
    content: "\e9a7"
}

.icon-portfolio:before {
    content: "\e9a8"
}

.icon-comments:before {
    content: "\e9a9"
}

.icon-screen3:before {
    content: "\e9aa"
}

.icon-iphone:before {
    content: "\e9ab"
}

.icon-ipad:before {
    content: "\e9ac"
}

.icon-googleplus5:before {
    content: "\e9ad"
}

.icon-pin:before {
    content: "\e9ae"
}

.icon-pin-alt:before {
    content: "\e9af"
}

.icon-cog5:before {
    content: "\e9b0"
}

.icon-graduation:before {
    content: "\e9b1"
}

.icon-air:before {
    content: "\e9b2"
}

.icon-droplets:before {
    content: "\e7ee"
}

.icon-statistics:before {
    content: "\e9b4"
}

.icon-pie5:before {
    content: "\e7ef"
}

.icon-cross:before {
    content: "\e9b6"
}

.icon-minus2:before {
    content: "\e9b7"
}

.icon-plus2:before {
    content: "\e9b8"
}

.icon-info3:before {
    content: "\e9b9"
}

.icon-info22:before {
    content: "\e9ba"
}

.icon-question7:before {
    content: "\e9bb"
}

.icon-help:before {
    content: "\e9bc"
}

.icon-warning2:before {
    content: "\e9bd"
}

.icon-add-to-list:before {
    content: "\e9bf"
}

.icon-arrow-left12:before {
    content: "\e9c0"
}

.icon-arrow-down12:before {
    content: "\e9c1"
}

.icon-arrow-up12:before {
    content: "\e9c2"
}

.icon-arrow-right13:before {
    content: "\e9c3"
}

.icon-arrow-left22:before {
    content: "\e9c4"
}

.icon-arrow-down22:before {
    content: "\e9c5"
}

.icon-arrow-up22:before {
    content: "\e9c6"
}

.icon-arrow-right22:before {
    content: "\e9c7"
}

.icon-arrow-left32:before {
    content: "\e9c8"
}

.icon-arrow-down32:before {
    content: "\e9c9"
}

.icon-arrow-up32:before {
    content: "\e9ca"
}

.icon-arrow-right32:before {
    content: "\e9cb"
}

.icon-switch2:before {
    content: "\e647"
}

.icon-checkmark5:before {
    content: "\e600"
}

.icon-ampersand:before {
    content: "\e9cc"
}

.icon-alert:before {
    content: "\e9cf"
}

.icon-alignment-align:before {
    content: "\e9d0"
}

.icon-alignment-aligned-to:before {
    content: "\e9d1"
}

.icon-alignment-unalign:before {
    content: "\e9d2"
}

.icon-arrow-down132:before {
    content: "\e9d3"
}

.icon-arrow-up13:before {
    content: "\e9da"
}

.icon-arrow-left13:before {
    content: "\e9d4"
}

.icon-arrow-right14:before {
    content: "\e9d5"
}

.icon-arrow-small-down:before {
    content: "\e9d6"
}

.icon-arrow-small-left:before {
    content: "\e9d7"
}

.icon-arrow-small-right:before {
    content: "\e9d8"
}

.icon-arrow-small-up:before {
    content: "\e9d9"
}

.icon-check:before {
    content: "\e9db"
}

.icon-chevron-down:before {
    content: "\e9dc"
}

.icon-chevron-left:before {
    content: "\e9dd"
}

.icon-chevron-right:before {
    content: "\e9de"
}

.icon-chevron-up:before {
    content: "\e9df"
}

.icon-clippy:before {
    content: "\f035"
}

.icon-comment:before {
    content: "\f02b"
}

.icon-comment-discussion:before {
    content: "\f04f"
}

.icon-dash:before {
    content: "\e9e2"
}

.icon-diff:before {
    content: "\e9e3"
}

.icon-diff-added:before {
    content: "\e9e4"
}

.icon-diff-ignored:before {
    content: "\e9e5"
}

.icon-diff-modified:before {
    content: "\e9e6"
}

.icon-diff-removed:before {
    content: "\e9e7"
}

.icon-diff-renamed:before {
    content: "\e9e8"
}

.icon-file-media:before {
    content: "\f012"
}

.icon-fold:before {
    content: "\e9ea"
}

.icon-gear:before {
    content: "\e9eb"
}

.icon-git-branch:before {
    content: "\e9ec"
}

.icon-git-commit:before {
    content: "\e9ed"
}

.icon-git-compare:before {
    content: "\e9ee"
}

.icon-git-merge:before {
    content: "\e9ef"
}

.icon-git-pull-request:before {
    content: "\e9f0"
}

.icon-graph:before {
    content: "\f043"
}

.icon-law:before {
    content: "\e9f1"
}

.icon-list-ordered:before {
    content: "\e9f2"
}

.icon-list-unordered:before {
    content: "\e9f3"
}

.icon-mail5:before {
    content: "\e9f4"
}

.icon-mail-read:before {
    content: "\e9f5"
}

.icon-mention:before {
    content: "\e9f6"
}

.icon-mirror:before {
    content: "\f024"
}

.icon-move-down:before {
    content: "\f0a8"
}

.icon-move-left:before {
    content: "\f074"
}

.icon-move-right:before {
    content: "\f0a9"
}

.icon-move-up:before {
    content: "\f0a7"
}

.icon-person:before {
    content: "\f018"
}

.icon-plus22:before {
    content: "\e9f7"
}

.icon-primitive-dot:before {
    content: "\f052"
}

.icon-primitive-square:before {
    content: "\f053"
}

.icon-repo-forked:before {
    content: "\e9f8"
}

.icon-screen-full:before {
    content: "\e9f9"
}

.icon-screen-normal:before {
    content: "\e9fa"
}

.icon-sync:before {
    content: "\e9fb"
}

.icon-three-bars:before {
    content: "\e9fc"
}

.icon-unfold:before {
    content: "\e9fe"
}

.icon-versions:before {
    content: "\e9ff"
}

.icon-x:before {
    content: "\ea00"
}


/*smart alert*/


/* ReSharper disable once InvalidValue */

#smartAlert {
    position: absolute;
    visibility: hidden;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1000
}

body > #smartAlert {
    position: fixed
}

#smartAlertBox {
    overflow: hidden;
    position: absolute
}

#smartAlertHeader {
    position: relative
}

#smartAlert[data-draggable="true"] #smartAlertHeader {
    cursor: move;
}

#smartAlert[data-ie="7"] #smartAlertHeader {
    width: expression((this.parentNode.clientWidth - parseInt(this.currentStyle['paddingLeft']) - parseInt(this.currentStyle['paddingRight']))+'px')
}

#smartAlertTitle {
    text-align: left
}

#smartAlertClose {
    display: none;
    position: absolute;
    cursor: pointer
}

#smartAlert[data-cancel="true"] #smartAlertClose {
    display: block
}

#smartAlertBody {
    display: table;
    width: 100%
}

#smartAlert[data-ie="7"] #smartAlertBody {
    display: block;
    border-collapse: collapse;
    border-spacing: 0;
    width: auto;
    width: expression(this.parentNode.clientWidth+'px')
}

#smartAlert[data-ie="7"] #smartAlertBody,
#smartAlert[data-ie="7"] #smartAlertBody td {
    margin: 0;
    padding: 0;
    outline: 0;
    border: 0;
    font-weight: inherit;
    font-style: inherit;
    font-size: 100%;
    font-family: inherit;
    vertical-align: baseline
}

#smartAlertIcon {
    display: table-cell;
    background-position: center center;
    background-repeat: no-repeat
}

#smartAlert[data-icon="false"] #smartAlertIcon {
    display: none
}

#smartAlertContent {
    display: table-cell;
    vertical-align: middle
}

#smartAlert[data-align="left"] #smartAlertContent {
    text-align: left
}

#smartAlert[data-align="center"] #smartAlertContent {
    text-align: center
}

#smartAlert[data-align="right"] #smartAlertContent {
    text-align: right
}

#smartAlert[data-ie="7"] #smartAlertContent {
    word-wrap: break-word
}

#smartAlertPrompt {
    display: block;
    width: 100%;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box
}

#smartAlertButtons {
    position: relative;
    text-align: center
}

#smartAlert[data-ie="7"] #smartAlertButtons {
    width: expression((this.parentNode.clientWidth - parseInt(this.currentStyle['paddingLeft']) - parseInt(this.currentStyle['paddingRight']))+'px')
}

.smartAlertButton {
    display: inline-block;
    cursor: pointer;
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none
}

#smartAlert[data-ie="8"] .smartAlertButton {
    position: relative
}

#smartAlert[data-ie="7"] .smartAlertButton {
    display: inline;
    width: 1px
}

.smartAlertButton:first-child,
.smartAlertButton.pie_first-child {
    margin-left: 0
}

#smartAlert[data-pie="htc"],
#smartAlert[data-pie="htc"] #smartAlertBox,
#smartAlert[data-pie="htc"] #smartAlertHeader,
#smartAlert[data-pie="htc"] #smartAlertContent,
#smartAlert[data-pie="htc"] #smartAlertScrollBar,
#smartAlert[data-pie="htc"] #smartAlertScrollDrag,
#smartAlert[data-pie="htc"] #smartAlertButtons,
#smartAlert[data-pie="htc"] #smartAlertButton,
#smartAlert[data-pie="htc"] .smartAlertButton {
    behavior: url(alert/Content/PIE.htc)
}

#smartAlert[data-pie="php"],
#smartAlert[data-pie="php"] #smartAlertBox,
#smartAlert[data-pie="php"] #smartAlertHeader,
#smartAlert[data-pie="php"] #smartAlertContent,
#smartAlert[data-pie="php"] #smartAlertScrollBar,
#smartAlert[data-pie="php"] #smartAlertScrollDrag,
#smartAlert[data-pie="php"] #smartAlertButtons,
#smartAlert[data-pie="php"] #smartAlertButton,
#smartAlert[data-pie="php"] .smartAlertButton {
    behavior: url(alert/Content/PIE.php)
}

.mCSB_container {
    width: auto;
    margin-right: 30px;
    overflow: hidden
}

.mCSB_container.mCS_no_scrollbar {
    margin-right: 0
}

.mCS_disabled > .mCustomScrollBox > .mCSB_container.mCS_no_scrollbar,
.mCS_destroyed > .mCustomScrollBox > .mCSB_container.mCS_no_scrollbar {
    margin-right: 30px
}

.mCustomScrollBox > .mCSB_scrollTools {
    width: 16px;
    height: 100%;
    top: 0;
    right: 0
}

.mCSB_scrollTools .mCSB_draggerContainer {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    height: auto
}

.mCSB_scrollTools a + .mCSB_draggerContainer {
    margin: 20px 0
}

.mCSB_scrollTools .mCSB_draggerRail {
    width: 2px;
    height: 100%;
    margin: 0 auto;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px
}

.mCSB_scrollTools .mCSB_dragger {
    cursor: pointer;
    width: 100%;
    height: 30px
}

.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
    width: 4px;
    height: 100%;
    margin: 0 auto;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
    text-align: center
}

.mCustomScrollBox > .mCSB_scrollTools {
    opacity: .75;
    filter: alpha(opacity=75);
    -ms-filter: alpha(opacity=75)
}

.mCustomScrollBox:hover > .mCSB_scrollTools {
    opacity: 1;
    filter: alpha(opacity=100);
    -ms-filter: alpha(opacity=100)
}

.mCSB_scrollTools .mCSB_draggerRail {
    background: #000;
    background: rgba(0, 0, 0, 0.4);
    filter: alpha(opacity=40);
    -ms-filter: alpha(opacity=40)
}

.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
    background: #fff;
    background: rgba(255, 255, 255, 0.75);
    filter: alpha(opacity=75);
    -ms-filter: alpha(opacity=75)
}

.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
    background: rgba(255, 255, 255, 0.85);
    filter: alpha(opacity=85);
    -ms-filter: alpha(opacity=85)
}

.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar {
    background: rgba(255, 255, 255, 0.9);
    -webkit-filter: alpha(opacity=90);
    -moz-filter: alpha(opacity=90);
    -o-filter: alpha(opacity=90);
    filter: alpha(opacity=90);
    -ms-filter: alpha(opacity=90)
}

.mCustomScrollBox {
    max-width: none!important
}

#smartAlert {
    background: rgba(255, 255, 255, 0.45);
    -pie-background: rgba(255, 255, 255, 0.45)
}

#smartAlertBox {
    margin: 25px;
    border: 1px solid #36424b;
    min-width: 270px;
    max-width: 500px;
    font-family: sans-serif;
    font-size: 13px;
    background-color: rgba(34, 34, 34, 0.98);
    border-radius: 3px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -webkit-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -moz-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -ms-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4);
    -o-box-shadow: 0 0 6px rgba(0, 33, 70, 0.1), 0 7px 25px rgba(17, 38, 84, 0.4)
}

#smartAlert[data-type="prompt"] #smartAlertBox {
    min-width: 310px
}

#smartAlert[data-ie="9"] #smartAlertBox {
    border-radius: 4px
}

#smartAlert[data-ie="8"] #smartAlertBox,
#smartAlert[data-ie="7"] #smartAlertBox {
    box-shadow: none
}

#smartAlertHeader {
    border-bottom: 1px solid #36424b;
    padding: 6px 41px 5px 10px;
    background-color: #414d57;
    background-image: linear-gradient(#57626c, #3c4852);
    background-image: -webkit-linear-gradient(#57626c, #3c4852);
    background-image: -moz-linear-gradient(#57626c, #3c4852);
    background-image: -o-linear-gradient(#57626c, #3c4852);
    background-image: -ms-linear-gradient(#57626c, #3c4852);
    -pie-background: linear-gradient(#57626c, #3c4852);
    box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -webkit-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -moz-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -ms-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset;
    -o-box-shadow: 0 1px rgba(255, 255, 255, 0.21) inset, 0 0 10px rgba(255, 255, 255, 0.07) inset
}

#smartAlertTitle {
    font-weight: 700;
    text-shadow: 0 -1px 1px rgba(2, 3, 3, 0.3);
    color: #fff;
    line-height: 13px
}

#smartAlertClose {
    top: 5px;
    right: 10px;
    width: 13px;
    height: 13px;
    background: url(img/close.png)
}

@media only screen and (min-device-pixel-ratio:2),
only screen and (-webkit-min-device-pixel-ratio:2),
only screen and (-moz-min-device-pixel-ratio:2),
only screen and (-o-min-device-pixel-ratio:21) {
    #smartAlertClose {
        background: url(/images/close.png);
        -webkit-background-size: 100%, 100%;
        -moz-background-size: 100%, 100%;
        -o-background-size: 100%, 100%;
        -ms-background-size: 100%, 100%;
        background-size: 100%, 100%
    }
}

#smartAlert[data-webkit] #smartAlertHeader,
#smartAlert[data-opera] #smartAlertHeader {
    border-radius: 2px 2px 0 0
}

#smartAlertIcon {
    width: 67px
}

#smartAlert[data-icon="info"] #smartAlertIcon {
    background-image: url(/images/S01/symbol_information_35.png)
}

#smartAlert[data-icon="confirm"] #smartAlertIcon {
    background-image: url(/images/symbol_check_35.png)
}

#smartAlert[data-icon="warning"] #smartAlertIcon {
    background-image: url(/images/symbol_exclamation_35.png)
}

#smartAlert[data-icon="error"] #smartAlertIcon {
    background-image: url(/images/symbol_error_35.png)
}

#smartAlert[data-icon="prompt"] #smartAlertIcon {
    background-image: url(/images/symbol_information_35.png)
}

@media only screen and (min-device-pixel-ratio:2),
only screen and (-webkit-min-device-pixel-ratio:2),
only screen and (-moz-min-device-pixel-ratio:2),
only screen and (-o-min-device-pixel-ratio:21) {
    #smartAlertIcon {
        background-size: 35px, 35px;
        -webkit-background-size: 35px, 35px;
        -moz-background-size: 35px, 35px;
        -o-background-size: 35px, 35px
    }
    #smartAlert[data-icon="info"] #smartAlertIcon {
        background-image: url(x2/info.png)
    }
    #smartAlert[data-icon="confirm"] #smartAlertIcon {
        background-image: url(x2/confirm.png)
    }
    #smartAlert[data-icon="warning"] #smartAlertIcon {
        background-image: url(x2/warning.png)
    }
    #smartAlert[data-icon="error"] #smartAlertIcon {
        background-image: url(x2/error.png)
    }
    #smartAlert[data-icon="prompt"] #smartAlertIcon {
        background-image: url(x2/prompt.png)
    }
}

#smartAlertContent {
    font: bold 12px "Times New Roman", Times, serif;
    padding: 26px 20px 26px 0;
    line-height: 20px;
    color: #d4d4d4
}

#smartAlert[data-icon="false"] #smartAlertContent {
    padding-left: 52px
}

#smartAlert[data-type="prompt"] #smartAlertContent {
    padding: 16px 20px 16px 0
}

#smartAlert[data-type="prompt"][data-icon="false"] #smartAlertContent {
    padding-left: 26px
}

#smartAlertScrollArea {
    margin-right: 36px
}

#smartAlertScrollBar {
    background-color: #dfeaf4!important
}

#smartAlertScrollDrag {
    background-color: #48545e
}

#smartAlertPrompt {
    border: 1px solid #abb1c9;
    padding: 5px;
    margin: 10px 0;
    font-family: sans-serif;
    font-size: 13px;
    line-height: 13px;
    color: #848484;
    background: 0;
    border-radius: 3px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -o-border-radius: 3px;
    -ms-border-radius: 3px;
    box-shadow: 0 1px 3px rgba(2, 3, 3, 0.12) inset;
    -webkit-box-shadow: 0 1px 3px rgba(2, 3, 3, 0.12) inset;
    -moz-box-shadow: 0 1px 3px rgba(2, 3, 3, 0.12) inset;
    -o-box-shadow: 0 1px 3px rgba(2, 3, 3, 0.12) inset;
    -ms-box-shadow: 0 1px 3px rgba(2, 3, 3, 0.12) inset
}

#smartAlertButtons {
    border-top: 1px solid rgba(0, 186, 255, 0.28);
    padding: 12px 13px 13px;
    background-color: rgba(34, 34, 34, 0.68)
}

#smartAlert[data-webkit] #smartAlertButtons,
#smartAlert[data-opera] #smartAlertButtons,
#smartAlert[data-ie="8"] #smartAlertButtons,
#smartAlert[data-ie="7"] #smartAlertButtons {
    border-radius: 0 0 2px 2px
}

.smartAlertButton {
    font: bold 12px "Times New Roman", Times, serif;
    font-style: normal;
    color: #d4d4d4;
    background: #252728;
    -ms-text-shadow: 0 -1px 1px #222;
    text-shadow: 0 -1px 1px #222;
    -ms-border-radius: 5px 5px 5px 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px 5px 5px 5px;
    border-radius: 5px 5px 5px 5px;
    padding: 6px 10px;
    cursor: pointer;
    margin: 0 auto;
    border: 1px rgba(0, 153, 204, 0.36) solid;
    min-width: 32px;
    font-weight: 700;
    line-height: 13px;
    padding: 9px 22px 7px;
    margin: 5px 10px 5px 15px
}

.smartAlertButton:hover {
    color: #fff;
    background: #2b2a2a;
    border: 1px rgba(176, 209, 87, 0.35) solid
}

.smartAlertButton2 {
    margin-left: 11px;
    border: solid 1px #415989;
    padding: 9px 22px 7px;
    min-width: 32px;
    font-weight: 700;
    line-height: 13px;
    text-shadow: 0 1px 1px rgba(255, 255, 255, 0.5);
    color: #424e58;
    color: #fff;
    background-color: #f4f6f9;
    background-color: #303335;
    background-image: linear-gradient(#303335, #303335 99%, #303335);
    background-image: -webkit-linear-gradient(#303335, #303335 99%, #303335);
    background-image: -moz-linear-gradient(#303335, #303335 99%, #303335);
    background-image: -o-linear-gradient(#303335, #303335 99%, #303335);
    background-image: -ms-linear-gradient(#303335, #303335 99%, #303335);
    -pie-background: linear-gradient(#303335, #303335 99%, #303335);
    border-radius: 3px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    box-shadow: 0 1px rgba(2, 3, 3, 0.05), 0 0 1px #415989 inset;
    -webkit-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 1px #415989 inset;
    -moz-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 1px #415989 inset;
    -ms-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 1px #415989 inset;
    -o-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 0 1px #415989 inset
}

.smartAlertButton2:hover {
    border: solid 1px #415989;
    background-color: #414141;
    background-image: linear-gradient(#414141, #414141);
    background-image: -webkit-linear-gradient(#414141, #414141);
    background-image: -moz-linear-gradient(#414141, #414141);
    background-image: -o-linear-gradient(#414141, #414141);
    background-image: -ms-linear-gradient(#414141, #414141);
    -pie-background: linear-gradient(#414141, #414141);
    box-shadow: 0 2px rgba(41, 230, 230, 0.7), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -webkit-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -moz-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -ms-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset;
    -o-box-shadow: 0 2px rgba(2, 3, 3, 0.05), 0 2px rgba(255, 255, 255, 0.25) inset, 0 0 5px rgba(255, 255, 255, 0.5) inset
}

.smartAlertButton.smartAlertActive2 {
    border: 1px solid #b0d157;
    box-shadow: 0 0 4px rgba(86, 122, 155, 0.4), 0 0 5px #415989 inset;
    -webkit-box-shadow: 0 0 4px rgba(86, 122, 155, 0.4), 0 0 2px #415989 inset;
    -moz-box-shadow: 0 0 4px rgba(86, 122, 155, 0.4), 0 0 2px #415989 inset;
    -o-box-shadow: 0 0 4px rgba(86, 122, 155, 0.4), 0 0 2px #415989 inset;
    -ms-box-shadow: 0 0 4px rgba(86, 122, 155, 0.4), 0 0 2px #415989 inset
}

.smartAlertButton.smartAlertClick {
    border: 1px solid #9ba8bc;
    background-color: #252728;
    background-image: linear-gradient(#252728, #252728);
    background-image: -webkit-linear-gradient(#252728, #252728);
    background-image: -moz-linear-gradient(#252728, #252728);
    background-image: -o-linear-gradient(#252728, #252728);
    background-image: -ms-linear-gradient(#252728, #252728);
    -pie-background: linear-gradient(#252728, #252728);
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) inset, 0 0 4px rgba(255, 255, 255, 0.5) inset;
    -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) inset, 0 0 4px rgba(255, 255, 255, 0.5) inset;
    -ms-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) inset, 0 0 4px rgba(255, 255, 255, 0.5) inset;
    -o-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) inset, 0 0 4px rgba(255, 255, 255, 0.5) inset
}

</style><div id="smartAlert" data-type="info" data-cancel="true" data-icon="warning" data-align="left" data-draggable="false" data-pie="htc" data-chrome="81" style="visibility: visible; display: block;">
    <div id="smartAlertBox" style="width: auto; top: 382px; left: 791px;">
        <div id="smartAlertHeader">
            <div id="smartAlertTitle" style="color:white;">HATA </div>
            <div id="smartAlertClose"></div>
        </div>
        <div id="smartAlertBody">
            <div id="smartAlertIcon"></div>
            <div id="smartAlertContent">
                <div id="smartAlertScroll" class="mCustomScrollbar _mCS_1 mCS_no_scrollbar" style="max-height: 160px;">
                    <div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0">
                        <div id="smartAlertScrollArea" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="ltr">İzin verilmeden içerik değiştirildi. </div>
                        <div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: none;">
                            <div class="mCSB_draggerContainer">
                                <div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; height: 0px; top: 0px;">
                                    <div class="mCSB_dragger_bar" style="line-height: 30px;" id="smartAlertScrollDrag"></div>
                                </div>
                                <div class="mCSB_draggerRail" id="smartAlertScrollBar"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="smartAlertButtons">
            <div class="smartAlertButton smartAlertActive" data-id="someId"><a href="https://forum.turkmmo.com/uye/2150134-nikoo85/">TURKMMO İLETİŞİM</a></div>
        </div>
        <div id="smartAlertButtons">
            <div class="smartAlertButton smartAlertActive" data-id="someId"><a href="https://api.whatsapp.com/send?phone=013867423317&text=Merhaba%20Ben%20Turkmmodan%20Tema%20Hakk%C4%B1nda%20Bir%20Ka%C3%A7%20Sorum%20Olacakt%C4%B1">WHATSAPP İLETİŞİM</a></div>
        </div>
    </div>
</div>
</body>