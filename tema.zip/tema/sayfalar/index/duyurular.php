<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>



                   
                        <div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Haberler ve Güncellemeler</div>
								<?php
     
        $duyurular = $db->query("SELECT konu,icerik,label,labels,tarih,seo FROM duyurular ORDER BY id DESC ");
        if($duyurular->rowCount())
        {
            foreach($duyurular as $duyuru)
            {

             ?>
                                <div class="panel-body">
                                    <table class="table table-striped table-hover haber-tablo">

                                        <tr>

                                            <td><a href="duyuru/<?=$duyuru["seo"];?>.html">
									<?=$WMinf->kisalt($duyuru["konu"], 25, '....'); ?> <br>
									<small><?=$WMinf->kisalt($duyuru["icerik"], 350, '!'); ?></small></a>
                                            </td>

                                            <td style="text-align:right;"><a href="duyuru/<?=$duyuru["seo"];?>.html"><span class="label label-danger">Daha fazla oku</span></a></td>
                                        </tr>

                                    </table>
                                </div>
<?php
	
}


	
}
else
{
	
echo ' <style>
.hata-err {
    color: #ffe991;
    background-color: #c00;
    border-color: #fb6767;
}
.hata {
    position: relative;
    padding: .75rem 1.25rem;
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 1px solid #153348;
    border-radius: 0;
    background-color: #102a3d;
    font-weight: 600;
}
</style>

<div class="hata-err mb-0 animated shake"><div style="background-color:red;"  class="hata"  >Duyuru Eklenmedi !</div></div>';
	
}
?>
                            </div>
                        </div>
                        <div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Facebook</div>
                                <div class="panel-body">
                                    <div id="fb" class="bg-light">
                                        <img src="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/static/images/loaders/brighter.gif" alt="" id="fbLoading" style="display: none; margin: 224px auto;">
                                        <div id="fb-root" class=" fb_reset">
                                            <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
                                                <div></div>
                                            </div>
                                        </div>
                                        <script>
                                            (function(d, s, id) {
                                                var js, fjs = d.getElementsByTagName(s)[0];
                                                if (d.getElementById(id)) return;
                                                js = d.createElement(s);
                                                js.id = id;
                                                js.src = "//connect.facebook.net/tr_TR/sdk.js#xfbml=1&version=v2.8";
                                                fjs.parentNode.insertBefore(js, fjs);
                                            }(document, 'script', 'facebook-jssdk'));
                                        </script>
                                        <center>
                                            <div class="fb-page fb_iframe_widget" id="fbContent" data-href="https://www.facebook.com/<?=$vt->sosyal(0);?>" data-tabs="timeline" data-width="462" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false"
                                                data-show-facepile="false" style="" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=&amp;container_width=0&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2F<?=$vt->sosyal(0);?>%2F&amp;locale=tr_TR&amp;sdk=joey&amp;show_facepile=false&amp;small_header=false&amp;tabs=timeline&amp;width=462"><span style="vertical-align: bottom; width: 462px; height: 500px;"><iframe name="f977e8c516a688" width="462px" height="1000px" data-testid="fb:page Facebook Social Plugin" title="fb:page Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v2.8/plugins/page.php?adapt_container_width=true&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D46%23cb%3Df2013beb07abf14%26domain%3Ddemo.<?=$vt->sosyal(0);?>.com%26origin%3Dhttps%253A%252F%252Fdemo.<?=$vt->sosyal(0);?>.com%252Ff348031b0b261c%26relation%3Dparent.parent&amp;container_width=0&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2F<?=$vt->sosyal(0);?>%2F&amp;locale=tr_TR&amp;sdk=joey&amp;show_facepile=false&amp;small_header=false&amp;tabs=timeline&amp;width=462" class="" style="border: none; visibility: visible; width: 462px; height: 500px;"></iframe></span></div>
                                        </center>
                                    </div>

                                </div>
                            </div>
                        </div>
                  
