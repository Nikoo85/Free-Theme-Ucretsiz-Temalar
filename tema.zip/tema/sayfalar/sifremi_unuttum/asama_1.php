<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="col-md-12 mobil-nopad">
    <div class="panel panel-buyuk">
        <div class="panel-heading">Şifremi Unuttum</div>
        <div class="panel-body">
            <form action="javascript:;" id="sifremi_unuttum" method="post" variable="sifremiunuttum" class="form-horizontal">
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Kullanıcı Adı </label>
					<input type="hidden" name="sifre_unuttum_token" value="<?=$ayar->sessionid;?>">
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="kullanici" id="login" maxlength="30">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mail Adresi</label>
                    <div class="col-sm-6">
                        <input type="email" class="form-control" name="email" id="email" maxlength="30">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Kontrol</label>
                    <div class="col-sm-6">
                        
                        <div class="g-recaptcha">

						<img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a>


						</div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Güvenlik Kodu</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="captcha_code" id="email" maxlength="30">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-6">
                        <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> Mail Gönder</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>