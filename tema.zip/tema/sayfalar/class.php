<?php

class server
{
	
public function lonca($limit = 5)
{
global $odb, $ayar;

$query = $odb->query("SELECT guild.name, player.name AS lider, player_index.empire AS bayrak, guild.level, guild.ladder_point,guild.id FROM player.guild
	LEFT JOIN player.player
	ON guild.master = player.id
	LEFT JOIN player.player_index
	ON player_index.id = player.account_id
	ORDER BY ladder_point DESC
	LIMIT 0, $limit");

$i = 0;
foreach($query as $row)	
$i++;
if($i == 0){
?>
<tr>
<style>
.hata-err {
    color: #ffe991;
    background-color: #c00;
    border-color: #fb6767;
}
.hata {
    position: relative;
    padding: .75rem 1.25rem;
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 1px solid #153348;
    border-radius: 0;
    background-color: #102a3d;
    font-weight: 600;
}
</style>

<div class="hata-err mb-0 animated shake"><div style="background-color:red;"  class="hata"  >LONCA BİLGİSİ YOK !</div></div>

</tr>
<?php
}else{
?>
							<table class="table table-siralama">
								<thead>
								<tr>
									<td>#</td>
									<td>Lonca Adı</td>
									<td style="text-align:center;">Puan</td>
								</tr>
								</thead>
								<tbody>
								
								
								<tr>
												<td><?=$i;?></td>
												<td><a href="#"><?=$row["name"];?></a></td>
												<td style="text-align:center;"><?=$row["ladder_point"];?></td>
											</tr>
								
																																</tbody>
							</table>
<?php
}

}

public function karakter($limit = 5)
{
global $odb, $ayar, $db;

$query = $odb->query("SELECT player.id,player.name,player.job,player.level,player.exp,player_index.empire,guild.name AS guild_name 
	  FROM player.player 
	  LEFT JOIN player.player_index 
	  ON player_index.id=player.account_id 
	  LEFT JOIN player.guild_member 
	  ON guild_member.pid=player.id 
	  LEFT JOIN player.guild 
	  ON guild.id=guild_member.guild_id
	  INNER JOIN account.account 
	  ON account.id=player.account_id
	  WHERE player.name NOT LIKE '[%]%' AND account.status!='BLOCK' ORDER BY player.level DESC, player.playtime DESC LIMIT 0,$limit");

$i = 0;
foreach($query as $row)	
$i++;
if($i == 0){
?>
<tr>
<style>
.hata-err {
    color: #ffe991;
    background-color: #c00;
    border-color: #fb6767;
}
.hata {
    position: relative;
    padding: .75rem 1.25rem;
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 1px solid #153348;
    border-radius: 0;
    background-color: #102a3d;
    font-weight: 600;
}
</style>

<div class="hata-err mb-0 animated shake"><div style="background-color:red;"  class="hata"  >OYUNCU BİLGİSİ YOK !</div></div>

</tr>
<?php
}else{
?>
							<table class="table table-siralama">
								<thead>
								<tr>
									<td>#</td>
									<td>Oyuncu Adı</td>
									<td style="text-align:center;">Level</td>
								</tr>
								</thead>
								<tbody>
								
								
								<tr>
												<td><?=$i;?></td>
												<td><a href="#"><?=$row["name"];?></a></td>
												<td style="text-align:center;"><?=$row["level"];?></td>
											</tr>
								

																																</tbody>
							</table>
<?php
}

}
	
}

?>