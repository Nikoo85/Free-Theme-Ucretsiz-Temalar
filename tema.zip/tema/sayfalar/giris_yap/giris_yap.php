<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="col-md-12 mobil-nopad">
    <div class="panel panel-buyuk">
        <div class="panel-heading">Giriş Yap</div>
        <div class="panel-body">
            <form action="javascript:;" id="giris" method="post" class="form-horizontal">
                <input type="hidden" name="kayit_token" value="<?=$ayar->sessionid;?>">
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Kullanıcı Adı </label>
                    <div class="col-sm-6">
                        <input class="form-control" name="username" onkeyup="turkce_kontrol(this)" type="text" value="">
                        <input type="hidden" value="<?=$ayar->sessionid;?>" name="giris_token" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Şifre</label>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" name="pass">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-6">
                        <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> Giriş Yap</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>