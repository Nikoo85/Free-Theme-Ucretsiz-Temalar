<div class="col-md-12 mobil-nopad">
    <div class="panel panel-buyuk">
        <div class="panel-heading">Kayıt Ol</div>
        <div class="panel-body">
            <div class="panel-body">
<script>
function refreshCaptcha() {
	$("img#captcha_code").attr('src','<?=WMcaptcha;?>');
}
</script>
                <form action="javascript:;" method="post" id="kaydol" class="form-horizontal">
				<input type="hidden" name="kayit_token" value="<?=$ayar->sessionid;?>">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Adınız ve Soyadınız: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="real_name" onkeyup="turkce_kontrol(this)" type="text" value="">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Kullanıcı Adı: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="username" onkeyup="turkce_kontrol(this)"  type="text" value="">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Şifre: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="pass" type="password">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Şifre (Tekrar): </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="pass_retry" type="password">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Karakter Silme Kodu: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="social_id" onkeyup="sayi_kontrol(this)" maxlength="7" type="text">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Telefon Numarası: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="phone_number" onkeyup="sayi_kontrol(this)" maxlength="11" type="text">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">E-Posta: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="eposta" type="text" value="">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Kontrol</label>
                        <div class="col-sm-5">
                            
                          
                           
                            <div class="g-recaptcha" > <img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a> </div>
                            
                        </div>
                    </div>
					<div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Güvenlik Kodu: </label>
                        <div class="col-sm-5">
                            <input class="form-control" name="captcha_code" type="text" autocomplete="off">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Kontrol</label>
                        <div class="col-sm-5">
                            
                          
                           
                            <div class="g-recaptcha" > <input type="checkbox" name="sozlesme" id="checkbox" value="1" checked style="float:none; margin:0; padding:0; height: 15px;"> </div>
							<label for="checkbox">
        <strong><a href="<?=$WMclass->ayar("base");?>uyelik_sozlesmesi.php" target="_blank" class="uyesozlesmelink">Üyelik ve Hizmet Sözleşmesi</a></strong> 'ni okudum ve kabul ediyorum.</label>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> Kayıt Ol</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>