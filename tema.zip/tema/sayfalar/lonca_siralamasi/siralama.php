<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>



<div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Lonca Sıralaması</div>
<div class="panel-body no-padding">
				                    <table class="table table-hermes">
                        <thead>
                        <tr>
                            <td>#</td>
                            <td style="text-align:left;">İsim</td>
                            <td class="hidden-xs">Level</td>
                            <td class="hidden-xs">Bayrak</td>
                            <td>Puan</td>
                            <td class="hidden-xs">Sonuçlar</td>
                        </tr>
                        </thead>
                        <tbody>
							<?php 
	$i = $limit;
	foreach($query as $row){
		
	$uyeler = $odb->prepare("SELECT COUNT(guild_member.pid) AS COUNT FROM player.guild_member WHERE guild_id = ?");
	$uyeler->execute(array($row["id"]));
	$uyeler = $uyeler->fetchColumn();
		
	$i++;
	?>
							 <tr>
                                    <td><?=$i;?></td>
                                    <td style="text-align:left;"><a href="#"><?=$row["name"];?></a></td>
                                    <td class="hidden-xs"><?=$row["level"];?></td>
                                    <td><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.png" alt=""></td>
                                    <td class="hidden-xs"><a href="#"><?=$row["ladder_point"];?></a></td>
                                    <td class="hidden-xs"><span class="label label-green"><?=$row["win"];?></span> | <span class="label label-draw"><?=$row["draw"];?></span> | 
									<span class="label label-red"><?=$row["loss"];?></span></td>
                                </tr>
									<?php 
	}
	?>
																			                        </tbody>
                    </table>
                            </div>
 
   

  

                                </div>
                            </div>
