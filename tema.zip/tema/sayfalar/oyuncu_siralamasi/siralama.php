<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Oyuncu Sıralaması</div>
<div class="panel-body no-padding">
				                    <table class="table table-hermes">
                        <thead>
                        <tr>
                            <td>#</td>
                            <td style="text-align:left;">İsim</td>
                            <td class="hidden-xs">Seviye</td>
                            <td>Bayrak</td>
                            <td class="hidden-xs">Lonca</td>
                            <td class="hidden-xs">Oyun Süresi</td>
                        </tr>
                        </thead>
                        <tbody>
	<?php 
	$i = $limit;
	foreach($query as $row){
	$i++;
	?>
								<tr>
                                    <td><?=$i;?></td>
                                    <td style="text-align:left;"><a href="#"><?=$row["name"];?></a></td>
                                    <td class="hidden-xs"><?=$row["level"];?></td>
                                    <td><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.png" alt="Nikoo85"></td>
                                    <td class="hidden-xs">
										                                            <a href="#"><?=($row["lonca"] == "") ? '<span style="color:red">Yok<span></span>' : '<a href="lonca/'.$row["lonca"].'">'.$row["lonca"].'</a>';?></a>
										                                    </td>
                                    <td class="hidden-xs"><?=$row["playtime"];?></td>
                                </tr>
									<?php 
	}
	?>
																															                        </tbody>
                    </table>
                            </div>
 
   

  

                                </div>
                            </div>