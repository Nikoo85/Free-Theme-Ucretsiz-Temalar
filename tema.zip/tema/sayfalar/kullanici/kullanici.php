<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Hesabım</div>
								                                <div class="panel-body">
				                <div class="col-md-6">
                    <div class="list-group">
                        <a href="kullanici/sifre-degistir" class="list-group-item">Şifre Değiştir</a>
						<?php if($vt->a("mail_degistir") == 1){?>
                        <a href="kullanici/mail-degistir" class="list-group-item">Mail Adresi Değiştir</a>
						<?php } ?>
                        <a href="kullanici/karakter-silme-sifresi-degistir" class="list-group-item">
						<?=($vt->a("karakter_silme_sifre") == 1 || $vt->a("karakter_silme_sifre") == 3) ? "K. Silme Ş. Değiştir" : "K. Silme Ş. İste";?></a>
                        <a href="kullanici/depo-sifre-degistir" class="list-group-item"><?=($vt->a("depo_sifre") == 1 || $vt->a("depo_sifre") == 3) ? "Depo Şifre Değiştir" : "Depo Şifre Gönder";?></a>
                        <a href="kullanici/bugdan-kurtar" class="list-group-item">Bugtan Kurtar</a>
                        <a href="market" class="list-group-item itemshop itemshop-btn iframe">Nesne Market</a>
                        <a href="destek" class="list-group-item itemshop itemshop-btn iframe">Destek Sistemi</a>
                        <a href="cikis-yap" class="list-group-item">Çıkış</a>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="list-group">
                        <div class="list-group-item"><b>Hesabım :</b> <?=$_SESSION[$vt->a("isim")."username"];?>  &nbsp; 
		<?php if($vt->a("kullanici_degis") != 3){?><a href="kullanici/kullanici-adi-degistir">(Değiştir)</a> <?php } ?></div>
                        <div class="list-group-item"><b>Email :</b> <?=$vt->uye("email");?> &nbsp; 
		<?php if($vt->a("mail_degistir") == 1){?><a href="kullanici/mail-degistir">(Değiştir)</a> <?php } ?></div>
                        <div class="list-group-item"><b>Telefon :</b> <?=$WMinf->kisalt($vt->uye("phone1"), 7, "****");?></div>
                        <div class="list-group-item"><b>Ejderha Parası :</b> <?=$vt->uye("coins");?></div>
                        <div class="list-group-item"><b>En Son Giriş Tarihi :</b> <?= $WMinf->tarih_format('j F Y , l,  H:i:s', $vt->uye("last_play"));  ?> </div>
                    </div>

                </div>

            </div>
                            </div>
                        </div>