<?php 
require_once 'sayfalar/class.php';

$srv = new server;

?>

<!DOCTYPE html>
<html>

<head>

    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index" />
    <meta http-equiv="Content-Language" content="pl" />
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="">
    <?php $wmcp->head(); ?>
    <?php $tema->stiller(); ?>
    <!-- /meta start -->

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=WM_tema;?>favicon.ico" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, Demo, emek, medium, metin, pvp server metin2" />
    <meta name="description" content="Demo pvp server Metin2 emek/zor." />
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article" />
    <meta property="og:url" content="" />
    <meta property="og:title" content="Metin2 PVP Server" />
    <meta property="og:description" content="Demo-Metin2 PVP Server. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!" />
    <meta property="og:image" content="<?=WM_tema;?>Nikoo85_floder/data/upload/0rT7Cp3w0k2Y9Mz.png" />
    <!-- /openGraph tags -->

    <link href="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/assets/css/animate.css" rel="stylesheet">
	<link href="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/assets/css/style.css" rel="stylesheet">
    <link href="<?=WM_tema;?>Nikoo85_floder/app/public/client/vesta/assets/css/fancybox.css" rel="stylesheet" type="text/css" media="screen" />
    <!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body>
<?php

			include 'WM_theme/WM_tema/tema/Nikoo85_floder/data/flags/language.php';


?>
    <div id="sonuc"></div>
 <style>

            .languagepicker {

                background-color: #FFF;

                display: inline-block;

                padding: 0;

                height: 40px;

                overflow: hidden;

                transition: all .3s ease;

                margin: 30px 0 0 0;

                vertical-align: top;

                float: left;

                position: fixed;

                right: 0px;

                z-index: 999;

            }

            

            .languagepicker:hover {

                /* don't forget the 1px border */

                height: 81px;

            }

            

            .languagepicker a {

                color: #000;

                text-decoration: none;

            }

            

            .languagepicker li {

                display: block;

                padding: 0px 10px;

                line-height: 40px;

                border-top: 1px solid #EEE;

            }

            

            .languagepicker li:hover {

                background-color: #EEE;

            }

            

            .languagepicker a:first-child li {

                border: none;

                background: #FFF !important;

            }

            

            .languagepicker li img {

                margin-top: 0px;

            }

            

            .roundborders {

                -webkit-border-top-left-radius: 5px;

                -webkit-border-bottom-left-radius: 5px;

                -moz-border-radius-topleft: 5px;

                -moz-border-radius-bottomleft: 5px;

                border-top-left-radius: 5px;

                border-bottom-left-radius: 5px;

            }

            

            .large:hover {

                height: 165px;

            }

        </style>

        <ul class="languagepicker roundborders large">

            <a href="javascript:void(0)">

                <li><img src="<?=WM_tema;?>Nikoo85_floder/data/flags/country/pictures/<?php print $json_languages['languages'][$language_code]; ?>.png" /></li>

            </a>

            <a href="index.php?lang=tr">

                <li><img src="<?=WM_tema;?>Nikoo85_floder/data/flags/country/pictures/tr.png" /></li>

            </a>

            <a href="index.php?lang=en">

                <li><img src="<?=WM_tema;?>Nikoo85_floder/data/flags/country/pictures/en.png" /></li>

            </a>

            <a href="index.php?lang=de">

                <li><img src="<?=WM_tema;?>Nikoo85_floder/data/flags/country/pictures/de.png" /></li>

            </a>

        </ul>
    <div class="container-fluid icerik">
        <div class="container">
            <div class="row">
                <div class="ust">
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <!-- Bootstrap Menü Barı Mobilde Görünecek Kısım -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
                            </div>

                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li><a href="anasayfa"><?php print $lang['anasayfa']; ?></a></li>
                                    <li><a href="kaydol"><?php print $lang['kaydol']; ?></a></li>
                                    <li><a href="oyunu-indir"><?php print $lang['indir']; ?></a></li>
                                    <li><a href="oyuncu-siralamasi"><?php print $lang['siralama']; ?></a></li>
                                    <li><a href="market" class="itemshop itemshop-btn iframe"><?php print $lang['market']; ?></a></li>
                                    <li><a href="#" target="_blank"><?php print $lang['forum']; ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                    <div class="logo" style="background: url(<?=WM_tema;?>Nikoo85_floder/data/upload/0rT7Cp3w0k2Y9Mz.png) center no-repeat;">
                    </div>
                    <div class="onlineoyuncu">
                        <span><b id="online_oyuncu">ERROR</b> kişi şuanda oyunda.</span>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="col-md-12 no-padding">
                        <a href="oyunu-indir">
                            <div class="oyunindir_btn">
                                Oyunu indir<small>Hemen Oyna!</small>
                            </div>
                        </a>
                    </div>
                    <?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
                    <div class="col-md-12 no-padding">

                        <div class="panel panel-kucuk">
                            <div class="panel-heading">Giriş Yap</div>
                            <div class="panel-body">
                                <form method="post" action="javascript:;" id="giris">
                                    <input type="hidden" name="giris_csrf_token" value="<?=$ayar->sessionid;?>" />
                                    <input type="hidden" value="<?=$ayar->sessionid;?>" name="giris_token" />
                                    <div class="form-group">
                                        <label for="HesapAdi" class="giris-label">Kullanıcı Adı</label>
                                        <div class="input-group">
                                            <span class="input-group-addon giris-addon" id="basic-addon1"><i class="glyphicon glyphicon-user"></i></span>
                                            <input type="text" class="form-control giris-input" name="username" placeholder="Kullanıcı Adı" aria-describedby="basic-addon1" required="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="HesapSifre" class="giris-label">Şifre</label>
                                        <div class="input-group">
                                            <span class="input-group-addon giris-addon" id="basic-addon2"><i class="glyphicon glyphicon-lock"></i></span>
                                            <input type="password" class="form-control giris-input" name="pass" placeholder="Şifre" aria-describedby="basic-addon2" required="">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-giris btn-block">Giriş Yap</button>
                                </form>
                                <div class="kayip-buttonlar">
                                    <a href="sifremi-unuttum">Şifremi Unuttum</a><br>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php }else{ ?>
                    <div class="col-md-12 no-padding">
                        <div class="panel panel-kucuk">
                            <div class="panel-heading">Üye Paneli</div>
                            <div class="panel-body">
                                Hoşgeldin ,
                                <?=$_SESSION[$vt->a("isim")."username"];?><br>

                                    <table class="UyePanelTablo">
                                        <tbody>
                                            <tr>
                                                <td>Ejderha Parası</td>
                                                <td>
                                                    <?=$vt->uye("coins");?>
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <a href="kullanici" class="btn btn-uyepanel btn-block">Hesabım</a>
                                    <a href="<?=$vt->url(11);?>" class="btn btn-uyepanel btn-block itemshop itemshop-btn iframe">Nesne Market</a>
                                    <a href="destek" class="itemshop itemshop-btn iframe btn btn-uyepanel btn-block">Destek Sistemi</a><br>
                                    <a href="cikis-yap" class="btn btn-uyepanel btn-block">Çıkış</a>
                            </div>
                        </div>
                    </div>
                    <?php } ?>

                    <div class="col-md-12 no-padding">
                        <div class="panel panel-kucuk">
                            <div class="panel-heading"><a href="oyuncu-siralamasi" style="color: white">Oyuncu Sıralaması</a>
                                <i class="glyphicon glyphicon-user cache-bilgi" data-toggle="tooltip" data-placement="right"></i>
                            </div>
                            <div class="panel-body no-padding">


                                <?=$srv->karakter(5);?>


                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 no-padding">
                        <div class="panel panel-kucuk">
                            <div class="panel-heading"><a href="lonca-siralamasi" style="color: white">Lonca Sıralaması</a>
                                <i class="glyphicon glyphicon-user cache-bilgi" data-toggle="tooltip" data-placement="right"></i>
                            </div>
                            <div class="panel-body no-padding">

                                <!-- Bu veri önbellekten gösterilmektedir. -->

                                <?=$srv->lonca(5);?>


                                    <!-- Ön bellek gösterimi burada sona ermektedir. -->
                            </div>
                        </div>
                    </div>
                </div>
                <br><br>
                <div class="col-md-9">

                    <div class="col-md-8 no-padding">
<?=$wmcp->orta();?>
                    </div>

                    <div class="col-md-4 no-padding">
                        <div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Etkinlik Takvimi </div>
                                <div class="panel-body no-padding">

                                    <div class="panel-body">
                                        <iframe src="<?=WM_tema;?>Nikoo85_floder/event/dynamic.php" style="border: none;
    width: 223px;
    height: 367px;" id="fancybox-frame"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-12 mobil-nopad">
                            <div class="panel panel-buyuk">
                                <div class="panel-heading">Sunucu İstatistikleri</div>
                                <div class="panel-body no-padding">

                                    <div class="panel-body">
                                        <table class="table table-striped table-hover" style="padding:15px;">

                                            <?php if($tema->istatistikler(1) == 1){ ?>
                                            <tr>
                                                <td>Bugün Girenler</td>
                                                <td style="text-align:right;"><span class="label label-success" id="rekor_online">ERROR</span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php if($tema->istatistikler(2) == 1){ ?>
                                            <tr>
                                                <td>Toplam Kayıt</td>
                                                <td style="text-align:right;"><span class="label label-success" id="toplam_kayit">ERROR</span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php if($tema->istatistikler(3) == 1){ ?>
                                            <tr>
                                                <td>Toplam Oyuncu</td>
                                                <td style="text-align:right;"><span class="label label-success" id="toplam_karakter">ERROR</span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php if($tema->istatistikler(4) == 1){ ?>
                                            <tr>
                                                <td>Toplam Lonca</td>
                                                <td style="text-align:right;"><span class="label label-success" id="toplam_lonca">ERROR</span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php if($tema->droplar(0) == 1 || $tema->droplar(1) == 1 || $tema->droplar(2) == 1 ){ ?>
                                            <?php if($tema->droplar(0) == 1){ ?>
                                            <tr>
                                                <td>Exp Kazanma:</td>
                                                <td style="text-align:right;"><span class="label label-success"> %<?=$tema->drop(1);?></span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php if($tema->droplar(1) == 1){ ?>
                                            <tr>
                                                <td>Yang Düşürme</td>
                                                <td style="text-align:right;"><span class="label label-success"> %<?=$tema->drop(1);?></span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php if($tema->droplar(2) == 1){ ?>
                                            <tr>
                                                <td>Eşya Düşürme</td>
                                                <td style="text-align:right;"><span class="label label-success" id="toplam_lonca"> %<?=$tema->drop(2);?></span></td>
                                            </tr>
                                            <?php } ?>
                                            <?php } ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <script>
                    var isMobile = {
                        Android: function() {
                            return navigator.userAgent.match(/Android/i);
                        },
                        BlackBerry: function() {
                            return navigator.userAgent.match(/BlackBerry/i);
                        },
                        iOS: function() {
                            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
                        },
                        Opera: function() {
                            return navigator.userAgent.match(/Opera Mini/i);
                        },
                        Windows: function() {
                            return navigator.userAgent.match(/IEMobile/i);
                        },
                        any: function() {
                            return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
                        }
                    };
                    if (isMobile.any()) {
                        //some code...
                        document.getElementById('facebookLike').style.display = 'none';
                    }
                </script>
            </div>
            <style>
                .discord-widget {
                    position: fixed;
                    bottom: 0;
                    z-index: 10;
                }

                .discord-widget.active {
                    right: 20px;
                }
            </style>
            <!--
    <a class="discord-widget animated bounceInLeft" href="https://discord.gg/g2peBGe" title="Join us on Discord">
        <img src="https://discordapp.com/api/guilds/614527101466312708/embed.png?style=banner2">
    </a>-->
            <div class="row">
                <div class="col-md-12">
                    <div class="footer">
                        <div class="footer_ust hidden-xs">
                            <ul>
                                <li><a href="oyunu-indir">Oyunu indir</a></li>
                                <li><a href="oyuncu-siralamasi">Oyuncu Sıralaması</a></li>
                                <li><a href="lonca-siralamasi">Lonca Sıralaması</a></li>
                                <li><a href="#">Üyelik Sözleşmesi</a></li>
                                <li><a class="itemshop itemshop-btn iframe" href="destek">Destek Sistemi</a></li>
                                <li><a class="itemshop itemshop-btn iframe" href="market">Nesne Market</a></li>
                                <li><a target="_blank" href="https://forum.turkmmo.com/uye/2150134-nikoo85/">Facebook</a></li>
                                <li><a target="_blank" href="https://forum.turkmmo.com/uye/2150134-nikoo85/">Tanıtım</a></li>
                            </ul>
                            <div style="clear:both"></div>
                        </div>
                        <div style="clear:both;"></div>

<?php eval(base64_decode('CiByZXF1aXJlX29uY2UgIlx4NGVceDY5XDE1M1wxNTdceDZmXHgzOFx4MzVceDVmXDE0NlwxNTRceDZmXDE0NFx4NjVceDcyXDU3XDE0NFwxNDFcMTY0XHg2MVw1N1wxNDZcMTU3XHg2Zlx4NzRcMTQ1XHg3Mlx4MmZceDY2XDE1N1wxNTdcMTY0XDE0NVwxNjJceDVmXDE1NlwxNTFcMTUzXHg2ZlwxNTdcNzBceDM1XHgyZVwxNjBcMTUwXHg3MCI7IA==')); ?>
                        <?php 
$tema->jquery($konum); 
?>
</body>

</html>